------------------------------------------------------------------

--------------------- description of R_files ---------------------

------------------------------------------------------------------

code to produce Figures 1 - 10.

figure1.R 
figure2.R
figure3.R
figure4.R
figure5.R
figure6.R
figure7.R
figure8.R
figure9.R
figure10.R

---------------------------------------------------------------------

runStanAlphaEqualsOne.R

code needed to run model with alpha parameters fixed at 1, 
model M3 in Table 1.

---------------------------------------------------------------------

runStanFullModel.R

code needed to run full model (age, gender and income quintiles 
as covariates), model M2 in Table 1. 

---------------------------------------------------------------------

runStanFullModel2000.R

call the full model with n = 2000, leaving out 1000 respondents in 
'data_files/leave.out.idx1000.txt'

---------------------------------------------------------------------
runStanFullModel2950.R

call the full model with n = 2950, leaving out 50 respondents in 
'data_files/leave.out.idx50.txt'

---------------------------------------------------------------------

runStanNoCovariates.R

code needed to run the model with no covariates,
 model M1 in Table 1.
 
---------------------------------------------------------------------

runStanThetaCentred.R 

code needed to run the model with theta centred on a linear function of 
the covariates, model M4 in Table 1.
---------------------------------------------------------------------

code to produce Tables 1 - 6.
 
table1.R
table2.R
table3.R
table4.R
table5.R
table6.R