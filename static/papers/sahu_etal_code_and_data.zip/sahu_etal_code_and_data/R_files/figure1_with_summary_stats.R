rm(list=ls())



## This is all we need to reproduce Figure 1
X <- read.table("Figure1_data.txt", head=T)
quint <-  structure(c(18000, 25000, 35000, 50000), .Names = c("20%", "40%", 
"60%", "80%"))


pdf(paste(path_output, "Figure1_V4.pdf", sep=""), width=12, height=5)#paper="a4r")


Pannels=matrix(c(rep(1,1),rep(2,3),rep(3,2)), nrow=1)
layout(Pannels)
#layout.show(3)


par(mar=c(5,2.5,5,0))
boxplot(scores[Midx],scores[Fidx],names=c("M","F"),cex.lab=1.5,cex.axis=1.2,ylab="Score", xlab="Gender", ylim=c(0,100), col=c("white", "coral2"))


par(mar=c(5,1,5,0.5))

boxplot(X$scores[X$ages<50 & X$gender==0],X$scores[X$ages<50 & X$gender==1],
X$scores[X$ages>=50 & X$ages<70 & X$gender==0],X$scores[X$ages>=50 & X$ages<70 & X$gender==1],
X$scores[X$ages>70 & X$gender==0],X$scores[X$ages>70 & X$gender==1],
names=c("<50 M","<50 F", "50-69 M","50-69 F","70+ M","70+ F"), col=rep(c("white", "coral2"), 3),
xlab="Age and gender", cex.axis=1.2,cex.lab=1.5, ylim=c(0,100), yaxt="n" )



par(mar=c(5,0.5,5,1))
boxplot(scores[which(X$income<quint[1])],scores[which( X$income>=quint[1] & X$income<quint[2])],
scores[which(X$income>=quint[2] & X$income<quint[3])],
scores[which( X$income>=quint[3] & X$income<quint[4])],
scores[which( X$income>=quint[4])], names=c("1","2","3","4","5"),
xlab="Income quintile",cex.axis=1.2, cex.lab=1.5,ylim=c(0,100), yaxt="n") 

dev.off()



score1 <- scores[which(X$income<quint[1])]
score2 <- scores[which( X$income>=quint[1] & X$income<quint[2])]
score3 <- scores[which( X$income>=quint[2] & X$income<quint[3])]
score4 <- scores[which( X$income>=quint[3] & X$income<quint[4])]
score5 <- scores[which( X$income>=quint[4])]
# sanity check
length(score1) + length(score2) + length(score3) + length(score4) + length(score5)



means <- c(mean(score1), mean(score2), mean(score3), mean(score4), mean(score5))
sds <- c(sd(score1), sd(score2), sd(score3), sd(score4), sd(score5))

sum_stats <- list(means=round(means, 2), sds=round(sds, 2))
sum_stats
