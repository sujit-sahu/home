rm(list=ls())

library(rstan)
library(foreign)

source_dir<-#source directory

setwd(source_dir)

path_data=file.path(source_dir, "data_files")

# load covariate data ----

srilanka_covariates<-read.table(file=paste(path_data, "srilanka_covariates.txt", sep=""))
attach(srilanka_covariates)

covariates<- cbind( (ages-mean(ages))/sd(ages),gender,
                    income2, income3, income4,income5)#

#read response data ----

data<-read.table("Data/CapacityRecoded_5cats.txt") 

obs_total<-matrix(NA,5,ncol(data))
for(j in 1:ncol(data)){
  obs_total[,j]<-table(data[,j])
}
colnames(obs_total)<-c("1","2","3","4","5","6","7","8","9","10","11","12","13",
                        "14","15","16","17")

# Extract Expected Totals and CI ----
simulate_response <- function(alpha,theta, beta, covariates, gamma) {
  covariate_score = covariates%*%gamma
  covariate_score_vector_aug<-c(0, rep(covariate_score, length(beta)))
  unsummed <- c(alpha*theta, alpha*(theta - beta))
  cumulative_sum<-cumsum(unsummed)
  numerators <- exp(cumulative_sum + covariate_score_vector_aug)
  denominator <- sum(numerators)
  response_probs <- numerators/denominator
  simulated_y <- sample(1:length(response_probs) , size = 1,prob = response_probs) 
  return(simulated_y)
}


gpcm_fit<-readRDS(file.path(source_dir,"outputFullModel/gpcm_fit.rds"))
stan_samples<-rstan::extract(gpcm_fit)
rm(gpcm_fit)

alpha_samples<-stan_samples$alpha
beta_samples<-stan_samples$beta
theta_samples<-stan_samples$theta
gamma_samples<-stan_samples$gamma


S = 1000
n = 3000 
J = 17
K = 5 

sim_data<-array(NA,dim = c(S,n,J))# the i,j response for the sth simulatd data set

set.seed(2018)
system.time(
for (set in 1:S){
for (j in 1:J){
for (i in 1:n){
sim_data[set,i,j] = ifelse(is.na(data[i,j]), NA, 
                           simulate_response(alpha = alpha_samples[set,j],
                                             theta = theta_samples[set,i],
                                             beta = beta_samples[set,4*(j-1) + (1:4)], 
                                             covariates = covariates[i,],
                                             gamma = gamma_samples[set,])
)
}}} 
)

total<-array(NA, dim = c(S,J,K))
for (set in 1:S){
  for (j in 1:J){
total[set,j,1:K]<-table(sim_data[set,1:n,j])
  }}


exp_total1<-apply(total[,,1],2,mean) 
exp_total2<-apply(total[,,2],2,mean)
exp_total3<-apply(total[,,3],2,mean)
exp_total4<-apply(total[,,4],2,mean)
exp_total5<-apply(total[,,5],2,mean)


#compute quantiles ----
lower_quantile <-function(x){ quantile(x,probs=c(0.025))  } 
upper_quantile <-function(x){ quantile(x,probs=c(0.975))  } 

lower_quantile1<-apply(total[,,1],2,lower_quantile)
lower_quantile2<-apply(total[,,2],2,lower_quantile)
lower_quantile3<-apply(total[,,3],2,lower_quantile)
lower_quantile4<-apply(total[,,4],2,lower_quantile)
lower_quantile5<-apply(total[,,5],2,lower_quantile)


upper_quantile1<-apply(total[,,1],2,upper_quantile)
upper_quantile2<-apply(total[,,2],2,upper_quantile)
upper_quantile3<-apply(total[,,3],2,upper_quantile)
upper_quantile4<-apply(total[,,4],2,upper_quantile)
upper_quantile5<-apply(total[,,5],2,upper_quantile)


#plot ----

pos<-c("1","2","3","4","5","6","7","8","9","10","11","12","13",
       "14","15","16","17")

ymin = min(lower_quantile1, lower_quantile2, lower_quantile3, lower_quantile4,lower_quantile5)
ymax = max(upper_quantile1, upper_quantile2, upper_quantile3, upper_quantile4,upper_quantile5)

dev.new()
plot(x=pos,y=exp_total1,pch=19,xlab="Item",ylab="Number of respondents",col="black",cex=0.7,
     lab=c(17,4,5),ylim=c(ymin,ymax))
segments(x0=1:17,y0=lower_quantile1,x1=1:17,y1=upper_quantile1)
segments(1:17-0.1, lower_quantile1, 1:17+0.1, lower_quantile1, col="black", lwd=1)
segments(1:17-0.1, upper_quantile1, 1:17+0.1, upper_quantile1, col="black", lwd=1)
segments(1:17-0.3, obs_total[1,], 1:17+0.3, obs_total[1,], col="red", lwd=1)

points(x=pos,y=exp_total2,pch=19,col="blue",cex=0.7)
segments(x0=1:17,y0=lower_quantile2,x1=1:17,y1=upper_quantile2,col="blue")
segments(1:17-0.1, lower_quantile2, 1:17+0.1, lower_quantile2, col="blue", lwd=1)
segments(1:17-0.1, upper_quantile2, 1:17+0.1, upper_quantile2, col="blue", lwd=1)
segments(1:17-0.3, obs_total[2,], 1:17+0.3, obs_total[2,], col="red", lwd=1)

points(x=pos,y=exp_total3,pch=19,col="green",cex=0.7)
segments(x0=1:17,y0=lower_quantile3,x1=1:17,y1=upper_quantile3,col="green")
segments(1:17-0.1, lower_quantile3, 1:17+0.1, lower_quantile3, col="green", lwd=1)
segments(1:17-0.1, upper_quantile3, 1:17+0.1, upper_quantile3, col="green", lwd=1)
segments(1:17-0.3, obs_total[3,], 1:17+0.3, obs_total[3,], col="red", lwd=1)

points(x=pos,y=exp_total4,pch=19,col="purple",cex=0.7)
segments(x0=1:17,y0=lower_quantile4,x1=1:17,y1=upper_quantile4, col="purple")
segments(1:17-0.1, lower_quantile4, 1:17+0.1, lower_quantile4, col="purple", lwd=1)
segments(1:17-0.1, upper_quantile4, 1:17+0.1, upper_quantile4, col="purple", lwd=1)
segments(1:17-0.3, obs_total[4,], 1:17+0.3, obs_total[4,], col="red", lwd=1)


points(x=pos,y=exp_total5,pch=19,col="gray",cex=0.7)
segments(x0=1:17,y0=lower_quantile5,x1=1:17,y1=upper_quantile5,col="gray")
segments(1:17-0.1, lower_quantile5, 1:17+0.1, lower_quantile5, col="gray", lwd=1)
segments(1:17-0.1, upper_quantile5, 1:17+0.1, upper_quantile5, col="gray", lwd=1)
segments(1:17-0.3, obs_total[5,], 1:17+0.3, obs_total[5,], col="red", lwd=1)

dev.copy2pdf(file="Figures/AllCIplot_stan.pdf",width=8,height=6)
