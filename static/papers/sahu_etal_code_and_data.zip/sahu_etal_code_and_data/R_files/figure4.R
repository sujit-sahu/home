rm(list=ls())

library(rstan)

source_dir<-#source directory

setwd(source_dir)


gpcm_estimates_full<-readRDS(file.path(source_dir,"outputFullModel/gpcm_estimates.rds"))
gpcm_estimates_no_cov<-readRDS(file.path(source_dir,"outputNoCovariates/gpcm_estimates.rds"))

J = 17

beta_full<-matrix(unname(gpcm_estimates_full[(J+1):(5*J),"mean"]),J,4,byrow = T )
beta_no_cov<-matrix(unname(gpcm_estimates_no_cov[(J+1):(5*J),"mean"]),J,4,byrow = T )


dat1 <- data.frame(x=beta_no_cov[,1], y=beta_full[,1], idx=1:J)
dat2 <- data.frame(x=beta_no_cov[,2], y=beta_full[,2], idx=1:J)
dat3 <- data.frame(x=beta_no_cov[,3], y=beta_full[,3], idx=1:J)
dat4 <- data.frame(x=beta_no_cov[,4], y=beta_full[,4], idx=1:J)


cex = 1.25
cex.lab = 1.5
cex.axis = 1.25

dev.new()
par(mfrow = c(2,2),mar=c(5, 5, 4, 2) + 0.1)#b,l,t,r
plot(y ~ x, data=dat1, type ="n",
     xlim = c(0.7,5.75), ylim = c(0.7,5.75),
     cex =cex, cex.lab = cex.lab, cex.axis=cex.axis,
     xlab = expression(paste(hat(beta)[2],"(no covariates)")),
     ylab = expression(paste(hat(beta)[2],"(covariates)"))
)
abline(a= 0, b = 1)
text(dat1$x,dat1$y,label=as.character(dat1$idx))

#par(mar=c(5, 5, 4, 2) + 0.1)#b,l,t,r
plot(y ~ x, data=dat2, type ="n",
     xlim = c(0.5,2.1), ylim = c(0.5,2.1),
     cex =cex, cex.lab = cex.lab, cex.axis=cex.axis,
     xlab = expression(paste(hat(beta)[3],"(no covariates)")),
     ylab = expression(paste(hat(beta)[3],"(covariates)"))
)
abline(a= 0, b = 1)
text(dat2$x,dat2$y,label=as.character(dat2$idx))

#par(mar=c(5, 5, 4, 2) + 0.1)#b,l,t,r
plot(y ~ x, data=dat3, type ="n",
     xlim = c(0.5,1.8), ylim = c(0.5,1.8),
     cex =cex, cex.lab = cex.lab, cex.axis=cex.axis,
     xlab = expression(paste(hat(beta)[4],"(no covariates)")),
     ylab = expression(paste(hat(beta)[4],"(covariates)"))
)
abline(a= 0, b = 1)
text(dat3$x,dat3$y,label=as.character(dat3$idx))

#par(mar=c(5, 5, 4, 2) + 0.1)#b,l,t,r
plot(y ~ x, data=dat3, type ="n",
     xlim = c(1.4,3.3), ylim = c(1.4,3.3),
     cex =cex, cex.lab = cex.lab, cex.axis=cex.axis,
     xlab = expression(paste(hat(beta)[5],"(no covariates)")),
     ylab = expression(paste(hat(beta)[5],"(covariates)"))
)
abline(a= 0, b = 1)
text(dat4$x,dat4$y,label=as.character(dat4$idx))

dev.copy2pdf(file="Figures/beta_cov_vs_nocov_with_4_panel_stan.pdf",width=8,height=8)