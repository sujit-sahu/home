rm(list=ls())

library(rstan)
library(foreign)

source_dir<-#source directory
  
setwd(source_dir)

path_data=file.path(source_dir, "data_files")

#read data----
SL_cap<-read.table(file=paste(path_data,"CapacityRecoded_5cats.txt", sep=""))
SL_cap<-as.matrix(SL_cap)
leave_out_idx<-read.table(file=paste(path_data,"leave.out.idx50.txt", sep=""))[,1]


leave_out_data<-SL_cap[leave_out_idx,]
SL_cap<-SL_cap[-leave_out_idx,]
srilanka_covariates<-read.table(file=paste(path_data, "srilanka_covariates.txt", sep=""))
attach(srilanka_covariates)

#shift and scale as the n = 2950 were
age_std = (ages-mean(ages[-leave_out_idx]))/sd(ages[-leave_out_idx]) 

covariates<- cbind( age_std,gender,income2, income3, income4,income5)

covariates <-covariates[leave_out_idx,]

#read mcmc samples----
S = 1000
l=length(leave_out_idx)
n = 3000 
J = 17
K = 5 


gpcm_fit<-readRDS(file.path(source_dir,"outputFullModel2950/gpcm_fit.rds"))
stan_samples<-rstan::extract(gpcm_fit)
rm(gpcm_fit)

alpha_samples<-stan_samples$alpha
beta_samples<-stan_samples$beta
theta_samples<-stan_samples$theta
gamma_samples<-stan_samples$gamma


xgamma<-matrix(NA,S,l)
for(i in 1:l){
  for(t in 1:S){
    xgamma[t,i]<-covariates[i,]%*%gamma_samples[t,] #make sure this is a scalar
  }
}

full.con<-function(alpha,beta,theta,xgamma,Kj=5,y){
eta<-c();psum<-c();exp.psum<-c();pijk<-c(); 

  for(j in 1:length(alpha)){
    eta[1]<- alpha[j]*(theta)
    psum[1]<-eta[1]
    exp.psum[1]<-exp(psum[1]) #
    for (k in 2:Kj){
      eta[k]<- alpha[j]*(theta-beta[j,k-1])#+xgamma 
      psum[k]<-sum(eta[1:k])+xgamma 
      exp.psum[k]<-exp(psum[k]) #denominator for each k
    }
    if(is.na(y[j])){
      pijk[j]=1;
    } else{
      pijk[j]<-exp.psum[as.numeric(y[j])]/sum(exp.psum)
    }
  }
  return(exp(-0.5*theta^2)*prod(pijk))
  
}#close function


# MH ----
theta_star_samples<-matrix(NA,S+1,length(leave_out_idx)); #to store samples, S by number of individual's scores to predict.
theta_star_samples[1,]<-0 #start values
overall_acc<-c()
adapt_scale_iter<-50
set.seed(46)

system.time(
  for(i in 1:length(leave_out_idx)){ 
    scale=1;acc=0;int_acc=0;
    
    for(t in 2:(S+1)){
      
      theta_prop<-rnorm(1,theta_star_samples[t-1,i],scale)
      
      prop<-full.con(alpha=alpha_samples[t-1,],beta=matrix(beta_samples[t-1,], nrow = J, byrow = TRUE),
                     theta=theta_prop, xgamma = xgamma[t-1,i], Kj=5,y=leave_out_data[i,])
      
      curr<-full.con(alpha=alpha_samples[t-1,],beta=matrix(beta_samples[t-1,], nrow = J, byrow = TRUE),
                     theta=theta_star_samples[t-1,i],xgamma = xgamma[t-1,i],Kj=5,y=leave_out_data[i,])
      
      acc_prob<-min(1,prop/curr)
      
      u<-runif(1)
      if(u<=acc_prob){
        theta_star_samples[t,i]=theta_prop;
        acc=acc+1;
        int_acc=int_acc+1;
      } else {
        theta_star_samples[t,i]=theta_star_samples[t-1,i]
      } #close if/else
      
      #adaptive scaling taken from Roberts and Rosenthal(2009) 'Examples of adaptive MCMC' Sec. 3.
      if(t%%adapt_scale_iter==0){
        if(int_acc==adapt_scale_iter*0.44){
          scale=scale;
        } else if(int_acc< adapt_scale_iter*0.44){
          scale=exp(log(scale)-(min(0.01,(t/adapt_scale_iter^0.5))));
        }else if(int_acc>adapt_scale_iter*0.44){
          scale=exp(log(scale)+(min(0.01,(t/adapt_scale_iter^0.5))));
        }
        
        int_acc=0;
      }
      
      
    }#close sampler
    
    overall_acc[i]<-acc
    
  } #close i loop
)
acc_rate<-overall_acc/S
theta_star_hat<-apply(theta_star_samples[2:(S+1),],2,mean)


#plot ----

gpcm_estimates_full<-readRDS(file.path(source_dir,"outputFullModel/gpcm_estimates.rds"))
theta_full<-unname(gpcm_estimates_full[5*J + (1:n),"mean"])

theta_star_2p5<-apply(theta_star_samples,2,quantile,probs=c(0.025))
theta_star_97p5<-apply(theta_star_samples,2,quantile,probs=c(0.975))

plot(theta_full[leave_out_idx],theta_star_hat,xlab="original estimate", ylab="predicted", pch="*")
abline(a=0,b=1)


plot(x=1:l,y=theta_star_hat,pch=19,xlab="Individual",ylab="Score",col="black",cex=1,las=0,
     lab=c(l,5,5),ylim=c(min(theta_star_2p5),max(theta_star_97p5)),xlim=c(2,l-1))
segments(x0=1:l,y0=theta_star_2p5,x1=1:l,y1=theta_star_97p5)
segments(1:l-0.1, theta_star_2p5, 1:l+0.1, theta_star_2p5, col="black", lwd=1)
segments(1:l-0.1, theta_star_97p5, 1:l+0.1, theta_star_97p5, col="black", lwd=1)
segments(1:l-0.3, theta_full[leave_out_idx], 1:l+0.3, theta_full[leave_out_idx], col="red", lwd=2)

dev.copy2pdf(file="Figures/95PIplot_stan.pdf",width=10,height=6)
