rm(list=ls())

library(rstan)

source_dir<-#source directory

setwd(source_dir)

gpcm_estimates_full<-readRDS(file.path(source_dir,"outputFullModel/gpcm_estimates.rds"))
gpcm_estimates_no_cov<-readRDS(file.path(source_dir,"outputNoCovariates/gpcm_estimates.rds"))

J = 17
n=3000

theta_full<-unname(gpcm_estimates_full[5*J + (1:n),"mean"])
theta_no_cov<-unname(gpcm_estimates_no_cov[5*J + (1:n),"mean"])

dat <- data.frame(x=theta_no_cov, y=theta_full)

dev.new()
cex = 1.25
cex.lab = 1.5
cex.axis = 1.5

par(mar=c(5, 5, 4, 2) + 0.1)#b,l,t,r
plot(y ~ x, data=dat, pch ="*",
     xlim = c(-2,4), ylim = c(-2,4),
     cex =cex, cex.lab = cex.lab, cex.axis=cex.axis,
     xlab = expression(paste(hat(theta),"(no covariates)")),
     ylab = expression(paste(hat(theta),"(covariates)"))
)
abline(a= 0, b = 1)

dev.copy2pdf(file="Figures/theta_cov_vs_nocov_item_number_stan.pdf",width=8,height=8)#