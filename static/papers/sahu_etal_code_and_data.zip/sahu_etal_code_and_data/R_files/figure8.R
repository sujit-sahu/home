rm(list=ls())

library(rstan)
library(foreign)

source_dir<-#source directory

setwd(source_dir)

path_data=file.path(source_dir, "data_files")


fisher<-function(theta,alpha,beta,Kj,xgamma){
  eta<-c();psum<-c();exp.psum<-c();v.for.deriv<-c();prob<-c();deriv<-c();fish<-c();
  
  eta[1]<-alpha*(theta-beta[1])
  psum[1]<-sum(eta[1:1])
  exp.psum[1]<-exp(psum[1])
  v.for.deriv[1]<-alpha*exp.psum[1]
  
  for (k in 2:Kj){
    eta[k]<- alpha*(theta-beta[k])
    psum[k]<-sum(eta[1:k])+xgamma
    exp.psum[k]<-exp(psum[k])
    v.for.deriv[k]<-k*alpha*exp.psum[k]
  }
  sum.exp.psum<-sum(exp.psum[1:Kj])
  d.bottom<-sum(v.for.deriv[1:Kj])
  
  for (k in 1:Kj){
    prob[k]<-exp.psum[k]/sum.exp.psum
    deriv[k]<-(k*alpha*exp.psum[k]*sum.exp.psum-exp.psum[k]*d.bottom)/(sum.exp.psum^2)
    fish[k]<-deriv[k]^2/prob[k]
  }
  return(sum(fish))
  
}#close function



# load covariate data ----
srilanka_covariates<-read.table(file=paste(path_data, "srilanka_covariates.txt", sep=""))
attach(srilanka_covariates)

covariates<- cbind( (ages-mean(ages))/sd(ages),gender,
                    income2, income3, income4,income5)#

# get parameter estimates----
m = ncol(covariates)
J=17

gpcm_estimates_full<-readRDS(file.path(source_dir,"outputFullModel/gpcm_estimates.rds"))

alpha_full<-unname(gpcm_estimates_full[1:J,"mean"])
beta_full<-cbind(c(rep(0,J)),matrix(unname(gpcm_estimates_full[(J+1):(5*J),"mean"]),J,4,byrow = T ))
theta_full<-unname(gpcm_estimates_full[5*J + (1:n),"mean"])
gamma_full<-unname(gpcm_estimates_full[5*J + n + (1:m),"mean"])

#produce theta profiles----
#A,F,I2,I3,I4,I5.
F50Q3<-gamma_full[1]*((50-mean(ages))/sd(ages))+gamma_full[2]+gamma_full[4]

item=c(1,2,11,10)

theta.mesh<-seq(-4,4,by=0.01)


plugin<-matrix(NA,length(theta.mesh),length(item))
for(j in 1:length(item)){
  for(i in 1:length(theta.mesh)){
    plugin[i,j]<-fisher(theta=theta.mesh[i],alpha=alpha_full[item[j]],
                        beta=beta_full[item[j],],Kj=5,xgamma=F50Q3)
  }
}


#plot----
dev.new()
par(mfrow=c(2,2),mar=c(4.5, 5.5, 3.5, 2) + 0.1)

plot(theta.mesh,plugin[,1],type="l",ylim=c(0,max(plugin[,1:2])),cex.lab=1.5,xlim=c(-4,4),
     xlab=expression(paste(theta)),ylab=expression(paste("I"[1](theta))))

plot(theta.mesh,plugin[,2],type="l",ylim=c(0,max(plugin[,1:2])),cex.lab=1.5,xlim=c(-4,4),
     xlab=expression(paste(theta)),ylab=expression(paste("I"[2](theta))))

plot(theta.mesh,plugin[,3],type="l",ylim=c(0,max(plugin[,3:4])),cex.lab=1.5,xlim=c(-4,4),
     xlab=expression(paste(theta)),ylab=expression(paste("I"[11](theta))))

plot(theta.mesh,plugin[,4],type="l",ylim=c(0,max(plugin[,3:4])),cex.lab=1.5,xlim=c(-4,4),
     xlab=expression(paste(theta)),ylab=expression(paste("I"[10](theta))))

dev.copy2pdf(file="Figures/fisher_pluginF50Q3_stan.pdf",width=10,height=6)