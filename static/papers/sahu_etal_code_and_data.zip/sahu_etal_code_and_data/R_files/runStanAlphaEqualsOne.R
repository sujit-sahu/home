
library(foreign)
library(rstan)

source_dir<-#source directory
  
setwd(source_dir)

data_dir=file.path(source_dir, "data_files")
stan_dir=file.path(source_dir, "stan_files")

SL_cap<-read.table(file=file.path(data_dir,"CapacityRecoded_5cats.txt"))

SL_cap<-as.matrix(SL_cap)

n = 3000
p = 17
J= p


SL_cap<-as.matrix(SL_cap[1:n,1:p])

srilanka_covariates<-read.table(file=file.path(data_dir,"srilanka_covariates.txt"))
attach(srilanka_covariates)

K<-c(rep(5,p))

#STAN data prep ----

gpcm_y = as.vector(t(SL_cap)) -1 #STAN takes values 0, 1,2,
jj <- rep(1:J, times = n)
nn <- rep(1:n, each = J)

idx<-which(is.na(gpcm_y))

N_mis<-length(idx)
jj_mis<-jj[idx]
nn_mis<-nn[idx]

if(length(idx)>0){
  gpcm_y_clean<-gpcm_y[-idx]
  jj_clean<-jj[-idx]
  nn_clean<-nn[-idx]
} else{
  gpcm_y_clean<-gpcm_y
  jj_clean<-jj
  nn_clean<-nn
}



covariates<- cbind( (ages-mean(ages))/sd(ages),gender,
                    income2, income3, income4,income5)
m= ncol(covariates)


chain_length = 2000
no_chains = 1

gpcm_list <- list( J = J, n = n, N = length(gpcm_y_clean), N_mis = N_mis, m = m,
                   jj = jj_clean, nn = nn_clean, jj_mis=jj_mis, nn_mis = nn_mis, 
                   K = K-1,covariates =  as.vector(t(covariates)),
                   y = gpcm_y_clean)



# fit STAN model ----

gpcm_fit <- stan(data=gpcm_list, file = file.path(stan_dir,"gpcmAlphaEqualsOne.stan"),seed = 2018,
                     chains = no_chains, iter = chain_length)

rds_name = paste0(deparse(substitute(gpcm_fit)), ".rds")
saveRDS(gpcm_fit, file = file.path("outputAlphaEqualsOne", rds_name))


gpcm_estimated_values <- summary(gpcm_fit,  
                                 pars = c( "beta", "theta", "gamma"),
                                 probs = c(.025, .975))


gpcm_estimates<- gpcm_estimated_values[["summary"]]
rds_name = paste0(deparse(substitute(gpcm_estimates)), ".rds")
saveRDS(gpcm_estimates, file = file.path("outputAlphaEqualsOne", rds_name))


