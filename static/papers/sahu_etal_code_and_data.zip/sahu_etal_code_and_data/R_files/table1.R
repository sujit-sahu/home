rm(list=ls())

library(xtable)
library(rstan)


source_dir<-#source directory
  
setwd(source_dir)


####Compute WAIC----
library(loo)

get.waic<-function(stan_object,verbose = FALSE){
  gpcm_fit = readRDS(stan_object)
  log_lik_samples = loo::extract_log_lik(gpcm_fit, parameter_name = "log_lik", merge_chains = TRUE)
  if(verbose){
    waic = waic(log_lik_samples)
  } else waic = suppressWarnings(waic(log_lik_samples))
  return(waic)  
}

FullModel<-get.waic( "outputFullModel/gpcm_fit_2018-09-25.rds")
Nocovariates<-get.waic( "outputNoCovariates/gpcm_fit_2018-09-24.rds")
AlphaEqualsOne<-get.waic( "outputAlphaEqualsOne/gpcm_fit_2018-09-25.rds")
ThetaCentred<-get.waic( "outputThetaCentred/gpcm_fit_2018-09-24.rds")

df_waic<-data.frame("measure" = c("p_waic", "waic"),
                    "M1" = c(Nocovariates$estimates[2:3]),
                    "M2" = c(FullModel$estimates[2:3]),
                    "M3" = c(AlphaEqualsOne$estimates[2:3]),
                    "M4" = c(ThetaCentred$estimates[2:3]))


tbl<- xtable(df_waic,
             caption = "WAIC for different models. A=age, G=gender, I=income as quintiles",
             label = "tab:WAIC",
             digits = 1,
             align = "llrrrr")
print(tbl, 
      file = "Tables/tab_waic.tex",
      caption.placement = "top",
      table.placement = "htb",
      include.rownames = FALSE)
