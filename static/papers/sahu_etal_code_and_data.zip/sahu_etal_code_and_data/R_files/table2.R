rm(list=ls())

library(rstan)
library(foreign)
library(xtable)

source_dir<-#source directory

setwd(source_dir)

path_data=file.path(source_dir, "data_files")

# load covariate data ----

srilanka_covariates<-read.table(file=paste(path_data, "srilanka_covariates.txt", sep=""))
attach(srilanka_covariates)

covariates<- cbind( (ages-mean(ages))/sd(ages),gender,
                    income2, income3, income4,income5)#

#read response data ----

data<-read.table("Data/CapacityRecoded_5cats.txt") 

obs_total<-matrix(NA,5,ncol(data))
for(j in 1:ncol(data)){
  obs_total[,j]<-table(data[,j])
}
colnames(obs_total)<-c("1","2","3","4","5","6","7","8","9","10","11","12","13",
                       "14","15","16","17")

# Extract Expected Totals and CI ----
simulate_response <- function(alpha,theta, beta, covariates, gamma) {
  covariate_score = covariates%*%gamma
  covariate_score_vector_aug<-c(0, rep(covariate_score, length(beta)))
  unsummed <- c(alpha*theta, alpha*(theta - beta))
  cumulative_sum<-cumsum(unsummed)
  numerators <- exp(cumulative_sum + covariate_score_vector_aug)
  denominator <- sum(numerators)
  response_probs <- numerators/denominator
  simulated_y <- sample(1:length(response_probs) , size = 1,prob = response_probs) 
  return(simulated_y)
}


gpcm_fit<-readRDS(file.path(source_dir,"outputFullModel/gpcm_fit_2018-09-25.rds"))
stan_samples<-rstan::extract(gpcm_fit)
rm(gpcm_fit)

alpha_samples<-stan_samples$alpha
beta_samples<-stan_samples$beta
theta_samples<-stan_samples$theta
gamma_samples<-stan_samples$gamma


S = 1000
n = 3000 
J = 17
K = 5 

sim_data<-array(NA,dim = c(S,n,J))# the i,j response for the sth simulatd data set

set.seed(2018)
system.time(
  for (set in 1:S){
    for (j in 1:J){
      for (i in 1:n){
        sim_data[set,i,j] = ifelse(is.na(data[i,j]), NA, 
                                   simulate_response(alpha = alpha_samples[set,j],
                                                     theta = theta_samples[set,i],
                                                     beta = beta_samples[set,4*(j-1) + (1:4)], 
                                                     covariates = covariates[i,],
                                                     gamma = gamma_samples[set,])
        )
      }}} 
)

#saveRDS(object = sim_data, file = "data_files/posterior_simulated_data.rds") 
#sim_data<-readRDS(file = "data_files/posterior_simulated_data.rds")

total<-array(NA, dim = c(S,J,K))
for (set in 1:S){
  for (j in 1:J){
    total[set,j,1:K]<-table(sim_data[set,1:n,j])
  }}

#element-wise comparison with t(obs_total)----

total_comparison<-array(NA, dim = c(S,J,K))
for (set in 1:S){
total_comparison[set,,]<-total[set,,] >= t(obs_total)  # NOTE STRICT INEQUALITY
}  
  
  

table_ppp<-array(NA, dim = c(J,K))

for(j in 1:J){
  for(k in 1:K){
    table_ppp[j,k]<-sum(total_comparison[,j,k])/S
    
  }
}
  
sum(table_ppp >= 0.5)


#print to file----
df_tab_ppp<-data.frame(table_ppp)
names(df_tab_ppp)<-c("1","2","3","4","5")


tbl<- xtable(df_tab_ppp,
             caption = "Posterior predictive p-values for 1000 replicated data sets",
             label = "tab:ppp;val",
             digits = 3,
             align = "rrrrrr")
print(tbl, 
      file = "Tables/tab_ppp_val.tex",
      caption.placement = "top",
      table.placement = "htb",
      include.rownames = TRUE)


