rm(list=ls())

library(rstan)

source_dir<-#source directory

setwd(source_dir)

#pick up output from runstanFullModel.R
output_file = file.path(source_dir, "outputFullModel", "gpcm_estimates.rds")

n = 3000
m = 6
J=17

gpcm_estimates_full<-readRDS(file.path(source_dir,output_file))

gamma_estimates<-unname(gpcm_estimates_full[5*J + n + (1:m),c("mean", "2.5%","97.5%") ])
gamma_estimates <-round(gamma_estimates,3)


rnames<-c("Estimate", "95\\% CI (Lower)", "95\\% CI (Upper)")
estimates<-data.frame(cbind(rnames, rbind(gamma_estimates[,1], gamma_estimates[,2], gamma_estimates[,3])))

names(estimates)<-c("Parameter", "Age", "F", "I2", "I3", "I4", "I5")

tbl<- xtable(estimates,
             caption = "Parameter Estimates",
             label = "tab:par_est",
             digits = 3,
             align = "llrrrrrr")
print(tbl, 
      file = "Tables/tab_gamma_estimates.tex",
      caption.placement = "top",
      table.placement = "htb",
      include.rownames = FALSE)



