rm(list=ls())

library(rstan)
library(foreign)
library(xtable)

source_dir<-#source directory

setwd(source_dir)

data_dir=file.path(source_dir, "data_files")

fisher<-function(theta,alpha,beta,Kj,xgamma){
  eta<-c();psum<-c();exp.psum<-c();v.for.deriv<-c();prob<-c();deriv<-c();fish<-c();
  
  eta[1]<-alpha*(theta-beta[1])
  psum[1]<-sum(eta[1:1])
  exp.psum[1]<-exp(psum[1])
  v.for.deriv[1]<-alpha*exp.psum[1]
  
  for (k in 2:Kj){
    eta[k]<- alpha*(theta-beta[k])
    psum[k]<-sum(eta[1:k])+xgamma
    exp.psum[k]<-exp(psum[k])
    v.for.deriv[k]<-k*alpha*exp.psum[k]
  }
  sum.exp.psum<-sum(exp.psum[1:Kj])
  d.bottom<-sum(v.for.deriv[1:Kj])
  
  for (k in 1:Kj){
    prob[k]<-exp.psum[k]/sum.exp.psum
    deriv[k]<-(k*alpha*exp.psum[k]*sum.exp.psum-exp.psum[k]*d.bottom)/(sum.exp.psum^2)
    fish[k]<-deriv[k]^2/prob[k]
  }
  return(sum(fish))
  
}#close function



# load covariate data ----
srilanka_covariates<-read.table(file=paste(path_data, "srilanka_covariates.txt", sep=""))
attach(srilanka_covariates)

covariates<- cbind( (ages-mean(ages))/sd(ages),gender,
                    income2, income3, income4,income5)#

# get parameter estimates----
m = ncol(covariates)

S = 1000
n = 3000 
J = 17
K = 5 

#pick up output from runstanFullModel.R
output_file = file.path(source_dir, "outputFullModel", "gpcm_estimates.rds")

gpcm_fit<-readRDS(file.path(source_dir,output_file))
stan_samples<-rstan::extract(gpcm_fit)
rm(gpcm_fit)

alpha_samples<-stan_samples$alpha
beta_samples<-stan_samples$beta
theta_samples<-stan_samples$theta
gamma_samples<-stan_samples$gamma



xgamma<-matrix(NA,S,n)
for(i in 1:n){
  for(t in 1:S){
    xgamma[t,i]<-covariates[i,]%*%gamma_samples[t,] #make sure this is a scalar
  }
}

F<-matrix(0,n,J)
system.time(
  for(i in 1:n){
    for(j in 1:J){
      for(t in 1:S){
        F[i,j]<-F[i,j]+fisher(theta=theta_samples[t,i],
                              alpha=alpha_samples[t,j],
                              beta=c(0,beta_samples[t,4*(j-1) + (1:4)]),
                              Kj=K,
                              xgamma=xgamma[t,i])
      }
    }
  }
)

F<-F/S

item_rank<-rank(apply(F,2,mean))

#rank plot----
pos<-c("0","1","2","3","4","5","6","7","8","9","10","11","12","13",
       "14","15","16","17")

F_perm<-F[,which(item_rank==1)]
for(j in 2:length(item_rank)){
  F_perm<-cbind(F_perm,F[,which(item_rank==j)])
}

rank_names<-c()
for(j in 1:length(item_rank)){
  rank_names[j]<-which(item_rank==j)
}
rank_names=as.character(rank_names)


#tabulate ----

J<-ncol(F)
total_fish<-sum(F)
item_sum<-apply(F,2,sum)
item_perc<-item_sum*100/total_fish

order<-c()
for(j in 1:J){
  order[j]<-which(item_rank==J-j+1)
}

cum_perc<-c()
cum_perc[1]<-item_perc[order[1]]
for(j in 2:J){
  cum_perc[j]<-cum_perc[j-1]+item_perc[order[j]]
}

tbl<-cbind(order,round(apply(F,2,mean)[order],2),round(item_perc[order],2),round(cum_perc,2))
colnames(tbl) = c("Step", "FIC", "% of FIC", "Cumulative %")

tbl<- xtable(tbl,
             caption = "Item ordering according to the estimated FIC values",
             label = "tab:info_percent_SL_cap5",
             digits = 2,
             align = "clrrr")
print(tbl, 
      file = "Tables/tab_cumulative_fisher.tex",
      caption.placement = "top",
      table.placement = "htb",
      include.rownames = FALSE)


