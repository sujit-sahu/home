rm(list=ls())

library(xtable)

source_dir<-#source directory

setwd(source_dir)

#read response data ----

data<-read.table("data_files/CapacityRecoded_5cats.txt") 

obs_total<-matrix(NA,ncol(data),5)
for(j in 1:ncol(data)){
  obs_total[j,]<-table(data[,j])
}
rownames(obs_total)<-c("1","2","3","4","5","6","7","8","9","10","11","12","13",
                       "14","15","16","17")

obs_total<-as.data.frame(obs_total)
colnames(obs_total)<-c("1","2","3","4","5")
obs_total$Total<-apply(obs_total,1,sum)

tbl<- xtable(obs_total,
             caption = "Observed Totals",
             label = "tab:totals",
             digits = 0,
             align = "crrrrrr")
print(tbl, 
      file = "Tables/tab_obs_totals.tex",
      caption.placement = "top",
      table.placement = "htb",
      include.rownames = TRUE)


