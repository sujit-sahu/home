rm(list=ls())

library(rstan)

source_dir<-#source directory

setwd(source_dir)

J=17

#pick up output from runstanFullModel.R
output_file = file.path(source_dir, "outputFullModel", "gpcm_estimates.rds")

gpcm_estimates_full<-readRDS(file.path(source_dir,output_file))

alpha_estimates<-unname(gpcm_estimates_full[1:J,c("mean", "2.5%","97.5%")])
beta_estimates<-matrix(unname(gpcm_estimates_full[(J+1):(5*J),c("mean")]),J,4,byrow = T )

beta_2p5<-matrix(unname(gpcm_estimates_full[(J+1):(5*J),c("2.5%")]),J,4,byrow = T )
beta_97p5<-matrix(unname(gpcm_estimates_full[(J+1):(5*J),c("97.5%")]),J,4,byrow = T )


alpha_estimates <-round(alpha_estimates,2)
beta_estimates <-round(beta_estimates,2)
beta_2p5 <-round(beta_2p5,2)
beta_97p5 <-round(beta_97p5,2)


alpha<-paste(alpha_estimates[,1],"(",alpha_estimates[,2],", " ,alpha_estimates[,3],")",
             sep = "")
beta2<-paste(beta_estimates[,1],"(",beta_2p5[,1],", " ,beta_97p5[,1],")",
             sep = "")
beta3<-paste(beta_estimates[,2],"(",beta_2p5[,2],", " ,beta_97p5[,2],")",
             sep = "")
beta4<-paste(beta_estimates[,3],"(",beta_2p5[,3],", " ,beta_97p5[,3],")",
             sep = "")
beta5<-paste(beta_estimates[,4],"(",beta_2p5[,4],", " ,beta_97p5[,4],")",
             sep = "")

par_est<-cbind(alpha, beta2, beta3, beta4, beta5)

tbl<- xtable(par_est,
             caption = "Estimates of $\\boldalpha$ and $\\boldbeta$ and their 95\\% credible intervals (CI)",
             label = "tab:item_par_est",
             digits = 2,
             align = "rrrrrr")
print(tbl, 
      file = "Tables/tab_item_estimates.tex",
      caption.placement = "top",
      table.placement = "htb",
      include.rownames = TRUE)



