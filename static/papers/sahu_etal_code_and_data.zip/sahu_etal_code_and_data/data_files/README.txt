-------------------------------------------------------------------

-------------------- description of data_files --------------------

-------------------------------------------------------------------

CapacityRecoded_5cats.txt 

An 3000 x 17 (n x J) dimensional data frame of responses.
Each item has responses from 1 to 5. 
Column headings relate to the item code in the original survey.

-------------------------------------------------------------------
Figure1_data.txt
An 3000 x 4 matrix to reproduce Figure 1.



leave.out.idx50.txt

50 randomly selected indices to set aside for validation of the
predictive modelling approach in Section 5.3, see Fig6.

-------------------------------------------------------------------

leave.out.idx1000.txt

1000 randomly selected indices to set aside for validation of the
predictive modelling approach in Section 5.3, see Fig7.
-------------------------------------------------------------------

srilanka_covariates.txt

Demographic information (Age, Gender, income quintile) for the 3000 
respondents of the survey


-------------------------------------------------------------------
