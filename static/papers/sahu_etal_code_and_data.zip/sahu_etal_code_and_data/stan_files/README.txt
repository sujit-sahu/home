---------------------------------------------------------------------

--------------------- description of stan_files ---------------------

---------------------------------------------------------------------

gpcmAlphaEqualsOne.stan 

Stan code called by runStanAlphaEqualsOne.R to run model M3, 
see Table 1. 
---------------------------------------------------------------------

gpcmFullModel.stan 

Stan code called by runStanFullModel.R to run model M2, see Table 1.

---------------------------------------------------------------------

gpcmNoCovariates.stan 

Stan code called by runStanNoCovariates.R to run model M1, see Table 1. 
---------------------------------------------------------------------

gpcmThetaCentred.stan 

Stan code called by runStanThetaCentred.R to run model M4, see Table 1. 

---------------------------------------------------------------------
