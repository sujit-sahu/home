
library(spBayes)

###### reading the data files #######################################
spcheck1<-read.table("data/AURN_data_07_11.txt",header=T)

position<-which(is.na(spcheck1$aqum_no2)==TRUE);
spcheck1$aqum_no2[position]=mean(spcheck1$aqum_no2,na.rm=T);
####
spcheck = data.frame(index=spcheck1$index, lon=spcheck1$lon, lat=spcheck1$lat, year=spcheck1$year, month=spcheck1$month, day=spcheck1$day, obs_no2=spcheck1$obs_no2);
spcheck$sqrtaqm = sqrt(spcheck1$aqum_no2);
spcheck$type=spcheck1$type;
spcheck = spcheck[order(spcheck$index, spcheck$year, spcheck$month, spcheck$day),];

###### Step for preparing the data files #########

index_data=unique(spcheck$index);
len_index=length(index_data);
coords_all = as.matrix(unique(cbind(spcheck[,2:3])));
######
index_data=unique(spcheck$index);
len_index=length(index_data);
######

abb=c("Rural","Urban","RKS"); 
name1=abb;

total_length=length(spcheck[,1]); 
addition=matrix(0,nrow=total_length,ncol=(2*length(abb)));

########
name=character(length=(2*length(name1)));
for(i in 1:(length(name1)))
{
  name[(2*i)-1] = paste("fac",i,sep="");
  name[2*i]=name1[i];
}
for(i in 1:len_index)
{
  pos1=c(which(spcheck[,1]==index_data[i]));
  type=spcheck$type[pos1[1]];  
  pos=which(abb==type);
  
    for(j in 1:length(pos1))
    {
      addition[pos1[j],((2*pos)-1)]<-1;
      addition[pos1[j],(2*pos)]<-spcheck$sqrtaqm[pos1[j]];
    }
  
}
colnames(addition)<-name;
deduc=c(1,2);
addition=addition[,-deduc];
spcheck=cbind(spcheck,addition);
spcheck=spcheck[,-9];

####
# Define the coordinates
co_ind<-as.matrix(unique(cbind(spcheck[,1:3])));

######## choosing the validation sites ########
set.seed(11)
SitePred<-c(4,9,28,30,32,44,50,75,102,108,111,122,130,175,194);

#sites for fitting
gh<-co_ind[,1];
sitefit<-gh[!gh %in% SitePred];

new <- sample(sitefit, size=(54-length(SitePred)), replace = FALSE, prob = NULL); 
SitePred <- append(SitePred, new); 

sitefit<-gh[!gh %in% SitePred];

#############
prediction_file <- merge(data.frame(index=SitePred), spcheck, by="index");
prediction_file<-prediction_file[order(prediction_file$index,prediction_file$year,prediction_file$month,prediction_file$day),];
##########
fitting_file<-merge(data.frame(index=sitefit), spcheck, by="index");
fitting_file<-fitting_file[order(fitting_file$index,fitting_file$year,fitting_file$month,fitting_file$day),];

pos= which(is.na(fitting_file$obs_no2)==F);
fitting_file = fitting_file[pos,];
##############

n.samples <- 3000
burnin=1000
p = 6;
beta.prior.mean <- rep(0, times=p)
beta.prior.precision <- matrix(100, nrow=p, ncol=p)
prior.shape <- 2;
prior.rate <- 1;
fitting_file$obs_no2 = sqrt(fitting_file$obs_no2);

m.1 <- bayesLMConjugate(obs_no2 ~sqrtaqm + fac2 + Urban + fac3 + RKS, data = fitting_file, n.samples, beta.prior.mean, beta.prior.precision, prior.shape, prior.rate);

summary(m.1$p.samples)

param = t(m.1$p.samples[burnin:n.samples, 1:p]);
sig.sq = m.1$p.samples[burnin:n.samples, p+1];

fit.covars = data.matrix(cbind(rep(1, dim(fitting_file)[1]), fitting_file[,c(8:12)]));

fitted = fit.covars %*% param;

fitted_value = rep(0, dim(fitted)[1]);
for(i in 1:dim(fitted)[2])
{
  cat(i, "\n");
  
  sample = rnorm(n=dim(fitted)[1], mean=fitted[,i], sd=rep(sqrt(sig.sq[i]), length(fitted[,i]))); 
  
  fitted_value = cbind(fitted_value, sample);
}
fitted_value = fitted_value[,-1];

penalty=0; gft=0;  
for(i in 1:dim(fitted_value)[1])
{
  penalty  = penalty + var(as.vector(fitted_value[i,]));
  gft = gft + (mean(fitted[i,])-sqrt(fitting_file$obs_no2[i]))^2;

}

PMCC = gft + penalty;

##################
pred.covars = data.matrix(cbind(rep(1, dim(prediction_file)[1]), prediction_file[,c(8:12)]));
predicted = pred.covars %*% param;

predicted_value = rep(0, dim(predicted)[1]);
for(i in 1:dim(predicted)[2])
{
  sample = rnorm(n=dim(predicted)[1], mean=predicted[,i], sd=rep(sqrt(sig.sq[i]), length(predicted[,i]))); 
  predicted_value = cbind(predicted_value, sample^2);
}
predicted_value = predicted_value[,-1];

lcl = apply(predicted_value, 1, function(x)quantile(x,0.025));
ucl = apply(predicted_value, 1, function(x)quantile(x,0.975));

count=0; total=length(which(is.na(prediction_file$obs_no2)==F));
for(i in 1:length(lcl))
{
  if((is.na(prediction_file$obs_no2[i])==F) & (lcl[i]<=prediction_file$obs_no2[i]) &(prediction_file$obs_no2[i]<ucl[i]))
  {
    count = count+1;
  }
}
prop = 100*count/total;

average_pred = apply(predicted_value, 1, FUN=mean);
diff = average_pred - prediction_file$obs_no2;

rmse = sqrt(mean(diff^2, na.rm=T));

mae = mean(abs(diff), na.rm=T);
bias = mean(diff, na.rm=T);
rbias = bias/mean(prediction_file$obs_no2, na.rm=T);

####### printing result will give row of Table 3 ############
result = matrix(0, nrow=1, ncol=5);

result[1,1] = rmse;  result[1,2] = mae; result[1,3] = bias; result[1,4]=prop; result[1,5] = (cor(average_pred, prediction_file$obs_no2, use="pairwise.complete.obs"))^2;
rownames(result) = c("Linear");
colnames(result) = c("RMSPE", "MAPE", "Bias", "Coverage (%)", "R2");

result




