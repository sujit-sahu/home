
spcheck1<-read.table("data/AURN_data_07_11.txt",header=T);


##### this plot will produce Figure 2 in the paper ############################
pdf(file="joint_box_type_daily.pdf", paper="a4");
par(mfrow=c(2,2))
boxplot(obs_no2~type, data=spcheck1, at=c(3,1,2), xlab=" ",ylab=" NO2",main=" ");
title(sub="(a): NO2");
boxplot(obs_ozone~type, data=spcheck1, at=c(3,1,2),xlab=" ",ylab=" O3",main=" ");
title(sub="(b): O3");
boxplot(obs_pm10~type, data=spcheck1, at=c(3,1,2),xlab=" ",ylab=" PM10",main=" ");
title(sub="(c): PM10");
boxplot(obs_pm2p5~type, data=spcheck1, at=c(3,1,2),xlab=" ",ylab=" PM2.5",main=" ");
title(sub="(d): PM2.5");
dev.off();
###################


spcheck1<-read.table("data/AURN_data_07_11.txt",header=T);

pdf(file="joint_box_year_daily.pdf", paper="a4");


par(mfrow=c(2,2))
boxplot(obs_no2~year, data=spcheck1,xlab=" ",ylab=" NO2",main=" ", las=1);
title(sub="(a): NO2");
boxplot(obs_ozone~year, data=spcheck1,xlab=" ",ylab=" O3",main=" ", las=1);
title(sub="(b): O3");
boxplot(obs_pm10~year, data=spcheck1,xlab=" ",ylab=" PM10",main=" ", las=1);
title(sub="(c): PM10");
boxplot(obs_pm2p5~year, data=spcheck1,xlab=" ",ylab=" PM2.5",main=" ", las=1);
title(sub="(d): PM2.5");


dev.off();

