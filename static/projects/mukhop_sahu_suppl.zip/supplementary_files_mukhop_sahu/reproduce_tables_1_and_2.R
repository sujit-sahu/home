

whole_data <- read.table("data/AURN_data_07_11.txt", head=T)

typedata = data.frame(type=c("Rural", "Urban", "RKS"), ruc=c(1,2,3));
whole_data = merge(whole_data, typedata, by=c("type"));


add = whole_data[,c(1:10, 19)];
pm2p5 = add; ozone = add; pm10=add; no2=add;
pm2p5$obs_pm2p5 = whole_data$obs_pm2p5;
ozone$obs_ozone = whole_data$obs_ozone; 
pm10$obs_pm10 = whole_data$obs_pm10;
no2$obs_no2 = whole_data$obs_no2;



######### Re-produce table 1 ###################

year_count = c((365*144), (366*144), (365*144), (365*144), (365*144));


pos1 = which(is.na(no2$obs_no2)==T);
total_prop_no2 = length(pos1)/length(no2$obs_no2);

no2 = no2[pos1,];
no2_tab_year = table(no2$year);
prop_no2 = 100*no2_tab_year/year_count;


pos1 = which(is.na(ozone$obs_ozone)==T);
total_prop_ozone = length(pos1)/length(ozone$obs_ozone);
ozone = ozone[pos1,];
ozone_tab_year = table(ozone$year);
prop_ozone = 100*ozone_tab_year/year_count;


pos1 = which(is.na(pm10$obs_pm10)==T);
total_prop_pm10 = length(pos1)/length(pm10$obs_pm10);
pm10 = pm10[pos1,];
pm10_tab_year = table(pm10$year);
prop_pm10 = 100*pm10_tab_year/year_count;


pos1 = which(is.na(pm2p5$obs_pm2p5)==T);
total_prop_pm2p5 = length(pos1)/length(pm2p5$obs_pm2p5);
pm2p5 = pm2p5[pos1,];
pm2p5_tab_year = table(pm2p5$year);
prop_pm2p5 = 100*pm2p5_tab_year/year_count;

Overall <- 100*c(total_prop_no2, total_prop_ozone, total_prop_pm10, total_prop_pm2p5)
table1 <- rbind(prop_no2, prop_ozone, prop_pm10, prop_pm2p5)
table1 <- cbind(table1, Overall)
dimnames(table1)[[1]] <- c("no2", "ozone", "pm10", "pm2p5")
table1 <- round(table1, 2)

## table1 above reproduces table 1


############## Table 2 AD column #######################

y <- whole_data

pos1 = which(!is.na(y$obs_no2))
no2 = y[pos1,];
no2_tab = table(no2$ruc);  #### no2 AD column
no2_tab_year = table(no2$year);

pos1 = which(!is.na(y$obs_ozone))
ozone = y[pos1,];
ozone_tab = table(ozone$ruc); ## ozone AD column
ozone_tab_year = table(ozone$year);

pos1 = which(!is.na(y$obs_pm10))
pm10 = y[pos1,];
pm10_tab = table(pm10$ruc); ## pm10 AD column
pm10_tab_year = table(pm10$year);

pos1 = which(!is.na(y$obs_pm2p5))
pm2p5 = y[pos1,];
pm2p5_tab = table(pm2p5$ruc); ## pm2p5 AD column
pm2p5_tab_year = table(pm2p5$year);


AD <- c(no2_tab,  sum(no2_tab),   ozone_tab, sum(ozone_tab),  pm10_tab, sum(pm10_tab),   pm2p5_tab,  sum(pm2p5_tab)) 

############## Table 2 rest of the columns ##############################################



minsno2 <- c(tapply(y$obs_no2, INDEX= y$ruc, FUN=min, na.rm=T), min(y$obs_no2, na.rm=T))
minsozone <- c(tapply(y$obs_ozone, INDEX= y$ruc, FUN=min, na.rm=T), min(y$obs_ozone, na.rm=T))
minspm10 <- c(tapply(y$obs_pm10, INDEX= y$ruc, FUN=min, na.rm=T), min(y$obs_pm10, na.rm=T))
minspm2p5 <- c(tapply(y$obs_pm2p5, INDEX= y$ruc, FUN=min, na.rm=T), min(y$obs_pm2p5, na.rm=T))

mins <- round(c(minsno2, minsozone, minspm10, minspm2p5), 2)

# All the minimums found 



mediansno2 <- c(tapply(y$obs_no2, INDEX= y$ruc, FUN=median, na.rm=T), median(y$obs_no2, na.rm=T))
mediansozone <- c(tapply(y$obs_ozone, INDEX= y$ruc, FUN=median, na.rm=T), median(y$obs_ozone, na.rm=T))
medianspm10 <- c(tapply(y$obs_pm10, INDEX= y$ruc, FUN=median, na.rm=T), median(y$obs_pm10, na.rm=T))
medianspm2p5 <- c(tapply(y$obs_pm2p5, INDEX= y$ruc, FUN=median, na.rm=T), median(y$obs_pm2p5, na.rm=T))

medians <- round(c(mediansno2, mediansozone, medianspm10, medianspm2p5), 2)


maxsno2 <- c(tapply(y$obs_no2, INDEX= y$ruc, FUN=max, na.rm=T), max(y$obs_no2, na.rm=T))
maxsozone <- c(tapply(y$obs_ozone, INDEX= y$ruc, FUN=max, na.rm=T), max(y$obs_ozone, na.rm=T))
maxspm10 <- c(tapply(y$obs_pm10, INDEX= y$ruc, FUN=max, na.rm=T), max(y$obs_pm10, na.rm=T))
maxspm2p5 <- c(tapply(y$obs_pm2p5, INDEX= y$ruc, FUN=max, na.rm=T), max(y$obs_pm2p5, na.rm=T))

maxs <- round(c(maxsno2, maxsozone, maxspm10, maxspm2p5), 2)


meansno2 <- c(tapply(y$obs_no2, INDEX= y$ruc, FUN=mean, na.rm=T), mean(y$obs_no2, na.rm=T))
meansozone <- c(tapply(y$obs_ozone, INDEX= y$ruc, FUN=mean, na.rm=T), mean(y$obs_ozone, na.rm=T))
meanspm10 <- c(tapply(y$obs_pm10, INDEX= y$ruc, FUN=mean, na.rm=T), mean(y$obs_pm10, na.rm=T))
meanspm2p5 <- c(tapply(y$obs_pm2p5, INDEX= y$ruc, FUN=mean, na.rm=T), mean(y$obs_pm2p5, na.rm=T))

means <- round(c(meansno2, meansozone, meanspm10, meanspm2p5), 2)

sdsno2 <- c(tapply(y$obs_no2, INDEX= y$ruc, FUN=sd, na.rm=T), sd(y$obs_no2, na.rm=T))
sdsozone <- c(tapply(y$obs_ozone, INDEX= y$ruc, FUN=sd, na.rm=T), sd(y$obs_ozone, na.rm=T))
sdspm10 <- c(tapply(y$obs_pm10, INDEX= y$ruc, FUN=sd, na.rm=T), sd(y$obs_pm10, na.rm=T))
sdspm2p5 <- c(tapply(y$obs_pm2p5, INDEX= y$ruc, FUN=sd, na.rm=T), sd(y$obs_pm2p5, na.rm=T))

sds <- round(c(sdsno2, sdsozone, sdspm10, sdspm2p5), 2)


table2 <- cbind(mins, medians, means, maxs, sds, AD)

dimnames(table2)[[1]] <- rep(c("Rural", "Urban", "RKS", "Combined"), 4)



