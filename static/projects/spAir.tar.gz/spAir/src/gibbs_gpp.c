
#include "main_gpp.h"
#include "covariance.h"
#include "common.h"
#include "mathematics.h"
#include "randgenerator.h"
#include "Print.h"
#include "string.h"

int dcomp(double *e1, double *e2)
{
  if (*e1 < *e2)
    return -1;
  else
    return 1;
}

int dcomp_decrease(double *e1, double *e2)
{
  if (*e1 > *e2)
    return -1;
  else
    return 1;
}

int icomp(int *e1, int *e2)
{
  if (*e1 < *e2)
    return -1;
  else
    return 1;
}

void  mean_var( b , n, mean , var)
double b[];
int n;
double *mean;
double *var;

{
 int i;
 double z1,z2,m1,m2;
 
 m1 = 0.0;
 m2 = 0.0;
 for ( i=0; i<n; i++)
 {
  m1 = m1+ b[i];
  m2 = m2 + sqr(b[i] );
 } 
  *mean = m1 / n; 
  z1 = m1 * m1;
  z1 = z1 / ( n * 1.0 );
  z1 = m2 - z1 ;
  z2 = z1/  (n -1.0) ;
  *var = z2 ;
}

int cmpfunc (const void * a, const void * b)
{
   return ( *(int*)a - *(int*)b );
}

void sumory(double *out, int n, int p, double *results)
{
 int i, j;
 double *x, u, v, lcl, ucl;
 
 x = malloc( n* sizeof(double) );
 
 //printf("\t \t Summary Statistics \n");
 //printf("Index \t Mean \t\t Sdev \t\t 2.5p \t\t 97.5p\n");
 
 for (j=0; j<p; j++) {
      for (i=0; i<n; i++) {
          x[i] = out[i*p+j];
      }
      qsort(x, n, sizeof(int), cmpfunc);  
      mean_var(x, n, &u, &v);
      v = sqrt(v);
      i = n * 0.025;
      lcl = x[i];
      i = n * 0.975;
      ucl = x[i];
      //printf("%d \t %4.4f \t %4.4f \t %4.4f \t %4.4f\n", j, u, v, lcl, ucl);
      results[(j*4)+0] = u; results[(j*4)+1] = v; results[(j*4)+2] = lcl; results[(j*4)+3] = ucl;
 }
     
 free(x);
 return;
}

void sort_values(double *out, int n)
{
  int i, j;
  double s1, s2, start;
  start=out[0];
  for(i=1; i<n; i++)
  {
    for(j=0; j<i; j++)
    {
      if(out[i]<out[j])
      {
        s1 = out[i];
        s2 = out[j];
        out[i] = out[j];
        out[j]=s1;
      }
    }
  }
  return;
}

// with all summary values (mean, variance/sd, low2.5, up97.5)
// also the predictions into another sites
// one phi value
// by defalt text output: as big data files
void GIBBS_sumpred_gpp_air(int *aggtype, int *cov, int *spdecay, double *flag, 
     int *its, int *burnin,
     int *n, int *m, int *T, int *r, int *rT, int *p, int *N, int *report,
     double *shape_e, double *shape_eta, double *shape_l,  
     double *phi_a, double *phi_b,
     double *prior_a, double *prior_b, double *mu_beta, double *delta2_beta,
     double *mu_rho,  double *delta2_rho, double *alpha_l, double *delta2_l,
     double *phi, double *tau, double *phis, int *phik,
     double *dm, double *dnm, int *constant, 
     double *sig2e, double *sig2eta, double *sig2l, double *beta, 
     double *rho, double *mu_l, double *X, double *z, double *w0, double *w,
     int *nsite, int *nsiterT, double *dnsm, double *Xpred, int *transform, 
     double *accept_f, double *gof, double *penalty,
     int *type_annual_fit, int *type_annual_grid, int *type_ann_la, int *joint_type, int *len_type_all, int *predloc, int *pred_limit, double *pred_info, double *grid_ann, 
     int *la_daily_info,int *la_ann_info, int *column_num, char **output_name)    
{
//     unsigned iseed = 44;
//     srand(iseed); 
     
     int its1, col, i, j, n1, m1, r1, rT1, p1, N1, rep1, nsite1, brin, trans1, effect_size, len_type_ann_la1, len_type_pred1, N_fit_trim;
     its1 = *its;
     col = *constant;
     n1 = *n;
     m1 = *m;
     r1 = *r;
     rT1 = *rT;
     p1 = *p;
     N1 = *N;
     rep1 = *report;
     nsite1 = *nsite;
     brin = *burnin;
     trans1 = *transform;

     effect_size = its1 - brin;
     Rprintf("name here : %s\n", *output_name);

     // len_type all = (size_of_daily_LA, size_of_annual_LA, size_of_annual_datasite_prediction);
     // len of data site = n1, length of predictive site = nsite1
     // time period for annual prediction at predictive site = size1,
     // size of MCMC sample after burnin = effect_size
    // predloc[0] = starting time point relative to data period for prediction at grid, predloc[1] = end time point relative to data period for predictive grid
    // predloc[2] = number of years in data sites, predloc[3]=number of years in predictive site, same for LA annual preidction 

     len_type_pred1 = len_type_all[0];  // size of daily LA
     len_type_ann_la1 = len_type_all[1];  // size of annual LA

     double max_data1;
     max_data1 = 800.0;
     Rprintf("max data here: %f %d\n", max_data1, predloc[0]);  
     Rprintf("length data here: %d %d\n", len_type_all[0], len_type_all[1]);  
     Rprintf("length data here: %f %f\n", sig2e[0], sig2l[0]);  

     int *size, size1; 
     size = (int *) malloc((size_t)((col)*sizeof(int))); 
     size[0] = (predloc[1] - predloc[0]) + 1;
     size1 = *size;
     N_fit_trim = size1*n1;   // the length of LA from data for aligned with the LA's of the grid

     Rprintf("n1=%d size1=%d fit=%d joint=%d, actual no.=%d\n", n1, size1, N_fit_trim, (size1*nsite1), len_type_pred1);
     Rprintf("site=%d time=%d, total=%d\n", nsite1, size1, (nsite1*size1)); 
     int pred_limit1, len_ann_fit1, len_ann_pred1;
     pred_limit1 = *pred_limit;

     len_ann_fit1 = predloc[2]; // number of years in data sites
     len_ann_pred1 = predloc[3];  // number of years in grids
  
     double accept1, *mn_rep, *var_rep, *mn_pred, *var_pred, *diff_z_xb, surface_making;
     mn_rep = (double *) malloc((size_t)((N1)*sizeof(double)));          
     var_rep = (double *) malloc((size_t)((N1)*sizeof(double)));          
     mn_pred = (double *) malloc((size_t)((nsite1*rT1)*sizeof(double)));          
     var_pred = (double *) malloc((size_t)((nsite1*rT1)*sizeof(double)));  
     diff_z_xb = (double *) malloc((size_t)((N1)*sizeof(double)));      

     accept1 = 0.0;

     for(j=0; j<N1; j++){
        mn_rep[j] = 0.0;
        var_rep[j] = 0.0;
     }      
     for(j=0; j<nsite1*size1; j++){
        mn_pred[j] = 0.0;
        var_pred[j] = 0.0;
     }      
     //Rprintf("up to first point\n");

     double *phip, *sig2ep, *sig2etap, *rhop, *betap;
     double *mu_lp, *sig2lp, *wp, *w0p, *zfit, *ofit, *acc;
     phip = (double *) malloc((size_t)((col)*sizeof(double)));          
     sig2ep = (double *) malloc((size_t)((col)*sizeof(double)));
     sig2etap = (double *) malloc((size_t)((col)*sizeof(double)));
     rhop = (double *) malloc((size_t)((col)*sizeof(double)));
     betap = (double *) malloc((size_t)((p1)*sizeof(double)));          
     mu_lp = (double *) malloc((size_t)((r1)*sizeof(double)));    
     sig2lp = (double *) malloc((size_t)((r1)*sizeof(double))); 
     wp = (double *) malloc((size_t)((m1*rT1)*sizeof(double))); 
     w0p = (double *) malloc((size_t)((m1*r1)*sizeof(double))); 
     zfit = (double *) malloc((size_t)((N1)*sizeof(double)));
     ofit = (double *) malloc((size_t)((N1)*sizeof(double)));     
     acc = (double *) malloc((size_t)((col)*sizeof(double)));

     double *phi1, *sig2e1, *sig2eta1, *rho1, *beta1, *w01, *w1;
     phi1 = (double *) malloc((size_t)((col)*sizeof(double)));
     sig2e1 = (double *) malloc((size_t)((col)*sizeof(double)));
     sig2eta1 = (double *) malloc((size_t)((col)*sizeof(double)));
     rho1 = (double *) malloc((size_t)((col)*sizeof(double)));
     beta1 = (double *) malloc((size_t)((p1*col)*sizeof(double)));     
     w01 = (double *) malloc((size_t)((m1*r1)*sizeof(double))); 
     w1 = (double *) malloc((size_t)((m1*rT1)*sizeof(double))); 

     double *zp, *out_fitted; // tmp[T1]; , *anf
     double *ave_type_joint, *count_joint, *count_annual_pred, *count_annual_fit;

     double *out_ann_fit, *save_ann_fit, *out_ann_pred, *save_ann_pred, *count_grid_ann;   //*out_prediction

     int ann_fit_size, ann_pred_size;

     ann_fit_size = n1*len_ann_fit1;   // size of the annual fitted values
     ann_pred_size = nsite1*len_ann_pred1; // size of the annual predicted values at grid locations

     count_annual_fit = (double *) malloc((size_t)((ann_fit_size)*sizeof(double)));
     out_ann_fit = (double *) malloc((size_t)((effect_size*ann_fit_size)*sizeof(double)));   // MCMC output for annual data sites
     save_ann_fit = (double *) malloc((size_t)((ann_fit_size)*sizeof(double)));  // save the annual data aggregation at a MCMC step

     if((predloc[0]==0) & (predloc[1]==(rT1-1))){
       zp = (double *) malloc((size_t)((nsite1*rT1)*sizeof(double)));      // output at grid locations at a MCMC step
       out_fitted = (double *) malloc((size_t)((effect_size*N1)*sizeof(double)));  // MCMC ouput for daily fitted values
               
       ave_type_joint = (double *) malloc((size_t)((len_type_pred1)*sizeof(double))); // LA aggregation at daily level at a MCMC step
       count_joint = (double *) malloc((size_t)((len_type_pred1)*sizeof(double)));     // number of sites in LA's at a MCMC step : used for calculating the mean
       
       out_ann_pred = (double *) malloc((size_t)((effect_size*ann_pred_size)*sizeof(double)));  // MCMC output for annual grid sites
       save_ann_pred = (double *) malloc((size_t)((ann_pred_size)*sizeof(double))); // save the annual grid aggregation at a MCMC step
       count_grid_ann = (double *) malloc((size_t)((ann_pred_size)*sizeof(double)));
     }     
  
     if((predloc[0]!=0) | (predloc[1]!=(rT1-1))){
       zp = (double *) malloc((size_t)((nsite1*size1)*sizeof(double)));     // output at grid locations at a MCMC step 
      
       out_fitted = (double *) malloc((size_t)((effect_size*N1)*sizeof(double))); // MCMC ouput for daily fitted values
                
       ave_type_joint = (double *) malloc((size_t)((len_type_pred1)*sizeof(double))); // LA aggregation at daily level at a MCMC step
       count_joint = (double *) malloc((size_t)((len_type_pred1)*sizeof(double)));     // number of sites in LA's at a MCMC step : used for calculating the mean
       
       out_ann_pred = (double *) malloc((size_t)((effect_size*ann_pred_size)*sizeof(double))); // MCMC output for annual grid sites
       save_ann_pred = (double *) malloc((size_t)((ann_pred_size)*sizeof(double)));            // save the annual grid aggregation at a MCMC step
       count_grid_ann = (double *) malloc((size_t)((ann_pred_size)*sizeof(double)));
     }                  

     for(j=0; j<(effect_size*N1); j++){
        out_fitted[j] = 0;
     }
 
     double *ave_ann_la, *sample_pred_LA, *count_ann_la, *sample_ann_LA, *save_ann_la;

     ave_ann_la = (double *) malloc((size_t)((len_type_ann_la1)*sizeof(double)));      // annual LA at a MCMC step
     sample_pred_LA = (double *) malloc((size_t)((effect_size*len_type_pred1)*sizeof(double))); // MCMC output for daily LA
     sample_ann_LA = (double *) malloc((size_t)((effect_size*len_type_ann_la1)*sizeof(double))); // MCMC output for annual LA
     count_ann_la = (double *) malloc((size_t)((len_type_ann_la1)*sizeof(double)));  // count of sites in LA's for calculating daily LA values
     save_ann_la = (double *) malloc((size_t)((len_type_ann_la1)*sizeof(double)));  // save annual LA at MCMC step

     for(j=0; j<(effect_size*len_type_pred1); j++){
        sample_pred_LA[j] = 0;
     }
     for(j=0; j<(effect_size*len_type_ann_la1); j++){
        sample_ann_LA[j] = 0;
     }

     double *nu, *nup;
     nu = (double *) malloc((size_t)((col)*sizeof(double)));
     nup = (double *) malloc((size_t)((col)*sizeof(double)));     
     nu[0] = 0.5;
          
       ext_sige(phi, phi1);
       ext_sige(sig2e, sig2e1);
       ext_sigeta(sig2eta, sig2eta1);
       ext_rho(rho, rho1);
       ext_beta(p, beta, beta1);
       for(j=0; j<m1*rT1; j++){
         w1[j] = w[j];
       }     
       for(j=0; j<m1*r1; j++){
         w01[j] = w0[j];
       }     

       // initialise the count of sites 
       for(j=0; j<len_type_ann_la1; j++)
       {    
         count_ann_la[j]=0;
       }
       for(j=0; j<len_type_pred1; j++)
       {    
         count_joint[j]=0;
       }
       for(j=0; j<ann_fit_size; j++)
       { 
         count_annual_fit[j]=0;
       }
       for(j=0; j<ann_pred_size; j++)
       { 
         count_grid_ann[j]=0;
       }
     
     // determine the name of the files
     //int name_var1, name_var2, name_var3, name_var=3;
     //name_var2 = name_var;    

     /*if(name_var2<10){
       name_var1 = name_var2/10;  name_var3 = name_var2 % 10;
     }
     if(name_var2>=10){
       name_var1 = name_var2/100;  name_var3 = name_var2 % 100; 
     }*/
     
     char str2[150], str21[150], str3[150], str4[150], str5[150], str6[150], str7[150], str8[150], str9[150], str10[100], str11[150]; 
     int name_var3;

     name_var3 = len_type_all[2];
     
       
     if(name_var3==10){
        Rprintf("achived my goal\n");
     }
     
     strcpy(str10, *output_name);
     strcpy(str2, str10);
     // determine output folder 
     strcpy(str21, str2);
     strcpy(str3, str2);
     strcpy(str4, str2); strcpy(str5, str2); strcpy(str6, str2); strcpy(str7, str2); strcpy(str8, str2); strcpy(str9, str2); strcpy(str11, str2);

     Rprintf("%s %s\n", str10, str2);
     strcat(str21, "_OutGPP_Values_Parameter.txt");
     FILE *parafile;
     parafile = fopen(str21, "w");

     //FILE *siglfile;
     //siglfile = fopen("OutGPP_Values_sigl.txt", "w");
     //FILE *wfile;
     //wfile = fopen("OutGPP_Values_w.txt", "w");

    
     //FILE *difffile;
     //difffile = fopen("OutGPP_Values_diff_z_xb.txt", "w");
     //printf("I have entered the code\n");

     strcat(str4, "_OutGPP_Stats_FittedValue.txt");
     printf("strcat( str1, str2):   %s\n", str4 );  
    
     FILE *fitfile;
     fitfile = fopen(str4, "w");
     //FILE *fittedfile;
     //fittedfile = fopen("Fitted_sites_mcmc1.txt", "w");        
  
     //FILE *fittedfile;
     //fittedfile = fopen("Fitted_sites_mcmc1.txt", "w");

     strcat(str5, "_OutGPP_Stats_PredValue.txt");
     FILE *prdfile;
     prdfile = fopen(str5, "w");
     //FILE *predfile;
     //predfile = fopen("Prediction_sites_mcmc1.txt", "w");

     strcat(str6, "_LA_predicted.txt");
     FILE *lapredfile;
     lapredfile = fopen(str6, "w");

     strcat(str7, "_LA_fitted.txt");
     FILE *lafitfile;
     lafitfile = fopen(str7, "w");
     int type1, type_aggrn;
     type1= *aggtype;
     //type_aggrn = *aggrn_type; 
     type_aggrn = 1;

     strcat(str8, "_Summary_joint_LA.txt");
     FILE *texttype1;
     texttype1 = fopen(str8, "w");

     strcat(str11, "_Prediction_daily_LA_limits.txt");
     FILE *summaryLApredfile;
     summaryLApredfile = fopen(str11, "w");
     
   
     // calculate the number counts for each aggregation
     int check_count_joint;
     int kkann;
    //Rprintf("I have came to the gate\n");
    check_count_joint = 0;
     for(j=0; j<(N_fit_trim+(nsite1*size1)); j++)
     { 
       //Rprintf("j=%d, kkann=%d, total_size=%d\n", j, joint_type[j], (N_fit_trim+(nsite1*size1))); 
       if(joint_type[j]>=0)
       { kkann = (int)joint_type[j];
         if(kkann>len_type_pred1){
               Rprintf("j=%d, kkann=%d\n", j, kkann); break;
           }
         count_joint[kkann] = count_joint[kkann] + 1;
       }     
     }
     //Rprintf("I have crossed the gate: check_count_joint = %d\n", check_count_joint);

     for(j=0; j<len_type_pred1; j++){
        check_count_joint = check_count_joint + count_joint[j];
     }
     //Rprintf("check the total : %d\n", check_count_joint);

     for(j=0; j<N1; j++){
        count_annual_fit[type_annual_fit[j]] = count_annual_fit[type_annual_fit[j]] + 1;
     }
     for(j=0; j<(N_fit_trim+(nsite1*size1)); j++){
        kkann = (int)type_ann_la[j];
        count_ann_la[kkann] = count_ann_la[kkann] + 1;
     }

     
     
     for(j=0; j< (nsite1*size1); j++){
        kkann = (int)type_annual_grid[j]; //Rprintf("j=%d, kkann = %d\n", j, kkann);
        if(kkann>nsite1){
           Rprintf("type_annual_grid problem : %d %d\n", kkann, type_annual_grid[j]); break;
        } 
        count_grid_ann[kkann] = count_grid_ann[kkann] + 1;  
     }

     //Rprintf("entering MCMC loop\n");
     GetRNGstate();            
     for(i=0; i < its1; i++) { 

     /*JOINT_onephi_gpp_air(cov, spdecay, flag, n, m, 
     T, r, rT, p, N, shape_e, shape_eta, 
     shape_l, phi_a, phi_b, prior_a, prior_b, mu_beta, delta2_beta, mu_rho,  delta2_rho, alpha_l, delta2_l, phi, tau, phis, phik, 
     nu, dm, dnm, constant, sig2e1, sig2eta1, sig2l, beta1, rho1, mu_l, X, z, w01, w1, phip, acc, nup, sig2ep, sig2etap, betap, rhop, mu_lp, sig2lp, w0p, wp, zfit, diff_z_xb);*/

     JOINT_onephi_gpp_fixed(cov, spdecay, flag, n, m, T, r, rT, p, N, 
     shape_e, shape_eta, shape_l, 
     phi_a, phi_b,
     prior_a, prior_b, mu_beta, delta2_beta, 
     mu_rho, delta2_rho, alpha_l, delta2_l, phi1, tau, phis, phik, nu, dm, dnm, 
     constant, sig2e1, sig2eta1, sig2l, beta1, rho1, mu_l, X, z, w01, w1, 
     phip, acc, nup, sig2ep, sig2etap, betap, rhop, mu_lp, sig2lp, w0p, wp, zfit, diff_z_xb);

     /*if(i >= brin){
     for(j=(posT1*m1); j<(rT1*m1); j++)
     {
       wpt[j - (posT1*m1)] = wp[j];
       fprintf(difffile, "%f ", wpt[j - (posT1*m1)]);
     } 
     fprintf(difffile, "\n");  
     for(j=0; j < m1*rT1; j++){
     fprintf(wfile, "%f ", wp[j]);
     }
     fprintf(wfile, "\n");  
     }*/
     //Rprintf("finished MCMC loop\n");
     if((predloc[0]==0) & (predloc[1]==(rT1-1))){
       z_pr_gpp1(cov, nsite, n, m, r, T, rT, p, nsiterT, phip, nup, dm, dnsm, 
       wp, sig2ep, betap, Xpred, constant, zp);
     }
     if((predloc[0]!=0) | (predloc[1]!=(rT1-1))){
       z_pr_gpp1_mod(cov, nsite, n, m, r, T, rT, p, nsiterT, phip, nup, dm, dnsm, 
       wp, sig2ep, betap, Xpred, constant, zp, predloc);
     }
     //Rprintf("finished prediction loop\n");
     accept1 += acc[0];

     for(j=0; j < p1; j++){
     fprintf(parafile, "%f ", betap[j]);
     }         
     fprintf(parafile, "%f ", rhop[0]);
     fprintf(parafile, "%f ", sig2ep[0]);
     fprintf(parafile, "%f ", sig2etap[0]);
     fprintf(parafile, "%f ", phip[0]);
     if(cov[0]==4){
      fprintf(parafile, "%f ", nup[0]);
     }     
     fprintf(parafile, "\n");
 
     /*for(j=0; j < r1; j++){
     fprintf(siglfile, "%f\n", sig2lp[j]);
     }
     for(j=0; j < m1*r1; j++){
     fprintf(w0file, "%f ", w0p[j]);
     }
     fprintf(w0file, "\n");    
     for(j=0; j < N1; j++)
     {
       fprintf(difffile, "%f\n", diff_z_xb[j]);
     }
     fprintf(difffile, "\n");*/
     
   //Rprintf("begin averaging\n");
       // initialise LA averages
       for(j=0; j<len_type_pred1; j++)
       { 
         ave_type_joint[j]=0;
       }
       
// for pmcc, fitted sum values    
     for(j=0; j < N1; j++){
         if(i >= brin){  
          mn_rep[j] += zfit[j];
          var_rep[j] += zfit[j]*zfit[j];
         } 
     }
     
    //Rprintf("start fit\n");
     // initialise the data annual 
     for(j=0; j<ann_fit_size; j++){
        save_ann_fit[j] = 0;
     }  
     for(j=0; j<len_type_ann_la1; j++){
        save_ann_la[j] = 0;
     }
     int mark, pcount;
     mark=0; pcount=0;
     if(i >= brin){
        for(j=0; j<N1; j++){
            if(trans1 == 0){
             out_fitted[((i-brin)*N1)+j] = zfit[j];
            }
           if(trans1 == 1){
             out_fitted[((i-brin)*N1)+j] = zfit[j]*zfit[j];
           }
           if(trans1 == 2){
             out_fitted[((i-brin)*N1)+j] = exp(zfit[j]); 
           }
           if(out_fitted[((i-brin)*N1)+j]>max_data1){
              Rprintf("Model outburst\n"); Rprintf("%f %f\n", out_fitted[((i-brin)*N1)+j], max_data1); break;
           }
           save_ann_fit[type_annual_fit[j]] = save_ann_fit[type_annual_fit[j]] + out_fitted[((i-brin)*N1)+j];  
           if((j >= ((mark*rT1) + predloc[0])) && (j <= ((mark*rT1) + predloc[1]))){
             if(joint_type[pcount]>=0)
             { 
               kkann = joint_type[pcount]; //Rprintf("j=%d, kkann=%d\n", pcount, kkann);
               if(kkann>len_type_pred1){
               Rprintf("j=%d, kkann=%d\n", j, kkann); break;
               }
               ave_type_joint[kkann] = ave_type_joint[kkann] + out_fitted[((i-brin)*N1)+j];      

               kkann = type_ann_la[pcount]; //Rprintf("j=%d, kkann=%d\n", pcount, kkann);  
               save_ann_la[kkann] = save_ann_la[kkann] + out_fitted[((i-brin)*N1)+j]; //Rprintf("j=%d, kkann=%d, zp=%f\n", j, kkann, out_fitted[((i-brin)*N1)+j]); 
               pcount = pcount+1;          
             }  
           }
           if(pcount==((mark+1)*(predloc[1]-predloc[0]+1)))
           {
             mark=mark+1;
           }    
         }

         //Rprintf("%d\n", ann_fit_size);
         for(j=0; j<ann_fit_size; j++){
           save_ann_fit[j] = save_ann_fit[j]/count_annual_fit[j]; 
           out_ann_fit[((i-brin)*ann_fit_size)+j] = save_ann_fit[j];   //Rprintf("%f\n", save_ann_fit[j]);
         }
     }  // brin loop

     //Rprintf("finish fit\n");

     for(j=0; j<ann_pred_size; j++){
          save_ann_pred[j] = 0;  
       } 
     // prediction samples
     
     double ind_print, ind_u, ind_v;
     if(i >= brin){
     for(j=0; j<(nsite1*size1); j++){
         if(trans1 == 0){
           zp[j] = zp[j];
           //fprintf(predfile, "%f ", zp[j]);
         }
         if(trans1 == 1){
           zp[j] = zp[j]*zp[j];
           //fprintf(predfile, "%f ", zp[j]);
         }
         if(trans1 == 2){
           zp[j] = exp(zp[j]);
           //fprintf(predfile, "%f ", zp[j]);
         }

         /*if(nsite1<=pred_limit1){
           out_prediction[((i-brin)*nsite1*rT1)+j] = zp[j]; 
         }*/
         //Rprintf("beaware 1\n");
         kkann = type_annual_grid[j];
         save_ann_pred[kkann] = save_ann_pred[kkann] + zp[j];   

         ind_print = (j+1)/365.0;
         ind_v = modf(ind_print, &ind_u);
         if((ind_v<0.001) && (zp[j]>max_data1) && (isnan(zp[j]))){
           Rprintf("j=%d, ind_print=%f, zp[j]=%f\n", j, ind_print, zp[j]);
         } 

         //Rprintf("j=%d kkann=%d site=%d time=%d, total=%d\n", j, kkann, nsite1, size1, (nsite1*size1)); 
         if((joint_type[N_fit_trim+j]>=0)){
           kkann = joint_type[N_fit_trim+j]; //Rprintf("j=%d, kkann=%d\n", j, kkann);
           if(kkann>len_type_pred1){
               Rprintf("j=%d, kkann=%d\n", j, kkann); break;
           }
           ave_type_joint[kkann] = ave_type_joint[kkann] + zp[j]; 

           kkann = type_ann_la[N_fit_trim+j];  
           save_ann_la[kkann] = save_ann_la[kkann] + zp[j]; //Rprintf("j=%d, kkann=%d, zp=%f\n", j, kkann, zp[j]); 
         }
     }                            
     //fprintf(predfile, "\n");

       //annual_aggregate_air(nsite, r, T, zp, save_ann_pred);
       for(j=0; j<ann_pred_size; j++){
          out_ann_pred[((i-brin)*ann_pred_size)+j] = save_ann_pred[j]/count_grid_ann[j];  
          /*if(j<=50){ 
            Rprintf("%d %f %f\n", j, save_ann_pred[j], save_ann_fit[j]);
          }*/
       } 
       //Rprintf("%d %d\n", nsite1, ann_pred_size);

     }  // brin loop	

     //Rprintf("come here for check\n");
     if(i >= brin){
       for(j=0; j<len_type_pred1; j++)
       { //Rprintf("clean cheat 1 : %d, value=%f\n", j, ave_type_joint[j]);
         if(count_joint[j]>0)
         {
           ave_type_joint[j] = ave_type_joint[j]/(double)count_joint[j]; 
           //Rprintf("length=%d size=%d j=%d count_joint=%d ave_type_joint : %f\n", len_type_pred1, check_count_joint, j, count_joint[j], ave_type_joint[j]);
           //fprintf(texttype1, "%f ", ave_type_joint[j]); 
         }
          //Rprintf("clean cheat 2 : %d, value=%f\n", j, ave_type_joint[j]);
           if(type_aggrn==1)
           {
             sample_pred_LA[((i-brin)*len_type_pred1)+j] = ave_type_joint[j];
           }           
         
       }
       //fprintf(lapredfile, "\n"); 
       if(count_joint[j]>0){
       //fprintf(texttype1, "\n"); 
       }
       //Rprintf("To achieve LA aggregation\n");  

       //int sizeann_la;
       //sizeann_la = (int)len_type_ann_la1/rT1;  Rprintf("year size of LA : %d\n", sizeann_la);
       //annual_aggregate_air(size_la, r, T, ave_type_joint, save_ann_la);  //(len_ann_pred1*(n1+nsite1))
  
       for(j=0; j<len_type_ann_la1; j++){
         if(count_ann_la[j]>0){
          save_ann_la[j] = save_ann_la[j]/count_ann_la[j];
         }
          sample_ann_LA[((i-brin)*len_type_ann_la1)+j] = save_ann_la[j];
          //Rprintf("ann la : %f, count=%f\n", save_ann_la[j], count_ann_la[j]);
       }

     } // brin loop
     
   //Rprintf("Achieved LA aggregation\n");
// prediction samples summary
     for(j=0; j<(nsite1*size1); j++){
         if(i >= brin){  
          mn_pred[j] += zp[j];
          var_pred[j] += zp[j]*zp[j];
         }
     }

       ext_sige(phip, phi1);
       ext_sige(sig2ep, sig2e1);
       ext_sigeta(sig2etap, sig2eta1); 
       ext_rho(rhop, rho1); 
       ext_beta(p, betap, beta1);              
       for(j=0; j<m1*rT1; j++){
         w1[j] = wp[j];
       }     
       for(j=0; j<m1*r1; j++){
         w01[j] = w0p[j];
       }     

     if(cov[0]==4){
     para_printRnu (i, its1, rep1, p1, accept1, phip, nup, rhop, sig2ep, sig2etap, betap); 
     }                   
     else {              
     para_printR (i, its1, rep1, p1, accept1, phip, rhop, sig2ep, sig2etap, betap); 
     }


 
     } // end of iteration loop
      
     //Rprintf("I can enter here\n");
     char strfit[150];
     strcpy(strfit, str2);
     strcat(strfit, "Fitted_sites_summary.txt");
     FILE *summaryfitfile;
     summaryfitfile = fopen(strfit, "w");
     // Producing summary
     double *x, u_mean, v_var, lcl, ucl;
 
     x = malloc( effect_size* sizeof(double) ); 
 
     /*if(nsite1<=pred_limit1){
       char strpred[150];
       strcpy(strpred, str2);
       strcat(strpred, "Prediction_sites_summary.txt");

       FILE *summaryfile;
       summaryfile = fopen(strpred, "w");
       for (j=0; j<(nsite1*rT1); j++) {
          for (i=0; i<effect_size; i++) {
            x[i] = out_prediction[i*(nsite1*rT1)+j];
          }
          sort_values(x, effect_size);
          mean_var(x, effect_size, &u_mean, &v_var);
          v_var = sqrt(v_var);
          i = effect_size * 0.025;
          lcl = x[i];
          i = effect_size * 0.975;
          ucl = x[i];
          
         fprintf(summaryfile,"%f  %f  %f  %f\n", u_mean, v_var, lcl, ucl);
       }
       fclose(summaryfile); 
    }*/
   

    // predicted annual    
     char strpredann[90];
     strcpy(strpredann, str2);
     strcat(strpredann, "_annual_average_predicted.txt");
     FILE *annualpredfile;
     annualpredfile = fopen(strpredann, "w");
     int column_num1;
     column_num1 = column_num[1];
     if(name_var3==1){
     fprintf(annualpredfile, "%s %s %s %s %s %s %s %s %s\n", "index", "lon", "lat", "year", "aqum", "pollutantpred", "sd", "95low", "95up");
     }

     int index, year;
     for(j=0; j<ann_pred_size; j++){
       for(i=0; i<effect_size; i++){
         x[i] = out_ann_pred[(i*ann_pred_size)+j];
       } 
       sort_values(x, effect_size);
       mean_var(x, effect_size, &u_mean, &v_var);
       v_var = sqrt(v_var);
       i = effect_size * 0.025;
       lcl = x[i];
       i = effect_size * 0.975;
       ucl = x[i];
          
       if((u_mean>max_data1) || (u_mean<lcl) || (u_mean>ucl)){
         Rprintf("outburst in daily grid : number=%d value=%f lcl=%f ucl=%f sd=%f", j, u_mean,lcl,ucl,v_var); break;
       }
       index = (int)grid_ann[(j*column_num1) + 0]; year = (int)grid_ann[(j*column_num1)+3];
       fprintf(annualpredfile,"%d %f %f %d %6.4f ",index,grid_ann[(j*column_num1)+1],grid_ann[(j*column_num1)+2],year,grid_ann[(j*column_num1)+4]);
       fprintf(annualpredfile,"%6.4f  %6.4f  %6.4f  %6.4f\n", u_mean, v_var, lcl, ucl);
     }
     fclose(annualpredfile); 

    //Rprintf("I can enter step 2\n");

    if(name_var3==1){ 
    fprintf(summaryfitfile, "%s %s %s %s\n", "pollutantfit", "sd", "95low", "95up");
    }
     for (j=0; j<N1; j++) {
      for (i=0; i<effect_size; i++) {
          x[i] = out_fitted[(i*N1)+j];
          }
          sort_values(x, effect_size);
          mean_var(x, effect_size, &u_mean, &v_var);
          v_var = sqrt(v_var);
          i = effect_size * 0.025;
          lcl = x[i];
          i = effect_size * 0.975;
          ucl = x[i];
          
         fprintf(summaryfitfile,"%6.4f  %6.4f  %6.4f  %6.4f\n", u_mean, v_var, lcl, ucl);
     }
      fclose(summaryfitfile); 
      //Rprintf("I can enter step 3\n");

     // fitted annual
     char strfitann[90];
     strcpy(strfitann, str2);
     strcat(strfitann, "_annual_average_fitted.txt");
     FILE *annualfitfile;
     annualfitfile = fopen(strfitann, "w");
     for(j=0; j<ann_fit_size; j++){
       for(i=0; i<effect_size; i++){
         x[i] = out_ann_fit[(i*ann_fit_size)+j];
       } 
       sort_values(x, effect_size);
       mean_var(x, effect_size, &u_mean, &v_var);
       v_var = sqrt(v_var);
       i = effect_size * 0.025;
       lcl = x[i];
       i = effect_size * 0.975;
       ucl = x[i];
          
       fprintf(annualfitfile,"%f  %f  %f  %f\n", u_mean, v_var, lcl, ucl);
     }
     fclose(annualfitfile); 
    //Rprintf("I can enter step 4\n");
     
       int month, day;
       if(name_var3==1){
         fprintf(summaryLApredfile, "%s %s %s %s %s %s %s %s\n", "indexla","year","month","day","pollutantfit", "sd", "95low", "95up");
       }
       column_num1 = column_num[2];
       for (j=0; j<(len_type_pred1-1); j++) {
       for (i=0; i<effect_size; i++) {
          x[i] = sample_pred_LA[(i*len_type_pred1)+j];
          }
          sort_values(x, effect_size);
          
          mean_var(x, effect_size, &u_mean, &v_var);
          v_var = sqrt(v_var);
          i = effect_size * 0.025;
          lcl = x[i];
          i = effect_size * 0.975;
          ucl = x[i];
          
        if((u_mean>max_data1) || (u_mean<lcl) || (u_mean>ucl)){
         Rprintf("outburst in daily LA : number=%d value=%f lcl=%f ucl=%f sd=%f", j, u_mean,lcl,ucl,v_var); break;
       }
       index = (int)la_daily_info[(j*column_num1) + 0]; year = (int)la_daily_info[(j*column_num1)+1]; month=(int)la_daily_info[(j*column_num1)+2];
       day=(int)la_daily_info[(j*column_num1)+3]; 
         if(v_var!=0){
         fprintf(summaryLApredfile,"%d %d %d %d ",index,year,month,day);

         fprintf(summaryLApredfile,"%f  %f  %f  %f\n", u_mean, v_var, lcl, ucl);
         }
       }

        
     

     char strannla[90];
     strcpy(strannla, str2);
     strcat(strannla, "_Prediction_annual_LA.txt");
     FILE *annLAfile;
     annLAfile = fopen(strannla, "w");
  
     column_num1 = column_num[3];  //Rprintf("%d %d\n", column_num1, len_type_ann_la1);
    if(name_var3==1){
         fprintf(annLAfile, "%s %s %s %s %s %s\n", "indexla","year","pollutantfit", "sd", "95low", "95up");
       }
     
     for(j=0; j<(len_type_ann_la1-1); j++){
       for(i=0; i<effect_size; i++){
         x[i] = sample_ann_LA[(i*len_type_ann_la1)+j];
       } 
       sort_values(x, effect_size);
       mean_var(x, effect_size, &u_mean, &v_var);
       v_var = sqrt(v_var);
       i = effect_size * 0.025;
       lcl = x[i];
       i = effect_size * 0.975;
       ucl = x[i];
          
       if((u_mean>max_data1) || (u_mean<lcl) || (u_mean>ucl)){
         Rprintf("outburst in annual LA : number=%d value=%f lcl=%f ucl=%f sd=%f", j, u_mean,lcl,ucl,v_var); break;
       }
       index = (int)la_ann_info[(j*column_num1)+0]; year = (int)la_ann_info[(j*column_num1)+1];

       if(v_var!=0){
       fprintf(annLAfile,"%d %d ",index,year); //Rprintf("%d %d %f %f\n", index, year, la_ann_info[(j*column_num1)+0], la_ann_info[(j*column_num1)+1]);
       fprintf(annLAfile,"%f  %f  %f  %f\n", u_mean, v_var, lcl, ucl);
       }
     }
     fclose(annLAfile);


     free(x);     
     fclose(summaryLApredfile);   
 

     PutRNGstate();

     fclose(parafile);
     //fclose(predfile);
     //fclose(fittedfile); 
     //fclose(textan);
     //fclose(siglfile);
    
     //fclose(wfile);
     //fclose(difffile);
     fclose(lafitfile);
     fclose(lapredfile);
     fclose(texttype1);
    
     free(size); //free(wpt);

    free(phip); free(sig2ep); free(sig2etap); free(rhop); free(betap); free(out_fitted);  
    free(mu_lp); free(sig2lp); free(wp); free(w0p); free(zfit); free(ofit); 
    free(acc); 
    free(phi1); free(sig2e1); free(sig2eta1); free(rho1); free(beta1);
    free(zp); free(diff_z_xb); 
    free(ave_type_joint); free(count_joint);
    //free(ave_type_pred); free(count_pred); free(anf);  
    //free(ave_type_fit); 
    free(count_annual_fit); free(count_grid_ann);
    free(out_ann_fit); free(save_ann_fit);
    free(out_ann_pred); free(save_ann_pred); 
    free(sample_pred_LA); free(ave_ann_la); free(count_ann_la); 
    free(sample_ann_LA); free(save_ann_la);

      //free(out_prediction); 

     Rprintf(" Calculating Summary Statistics \n ... ");

     accept_f[0] = accept1;

//     int iit;
//     iit = 0;
//     iit = its1 - brin;

	int *iit;
    iit = (int *) malloc((size_t)((col)*sizeof(int)));
	iit[0] = its[0] - burnin[0];

// fitted zlt, mean and sd
     for(j=0; j < N1; j++){
          mn_rep[j] = mn_rep[j]/iit[0];
          var_rep[j] = var_rep[j]/iit[0];
          surface_making = var_rep[j];
          var_rep[j] = var_rep[j] - mn_rep[j]*mn_rep[j];
          fprintf(fitfile, "%f %f \n", surface_making, sqrt(var_rep[j]));
     }
     fclose(fitfile);

// pred mean and sd

Rprintf("arrive here\n");
column_num1 = column_num[0];
      if(name_var3==1){
         fprintf(prdfile, "%s %s %s %s %s %s %s %s %s\n", "index", "lon", "lat", "year", "month", "day", "aqum", "pollutantpred", "sd");
       }
     for(j=0; j < (nsite1*size1); j++){
          mn_pred[j] = mn_pred[j]/iit[0];
          var_pred[j] = var_pred[j]/iit[0];
          var_pred[j] = var_pred[j] - mn_pred[j]*mn_pred[j];

         index = (int)pred_info[(j*column_num1) + 0]; year = (int)pred_info[(j*column_num1)+3]; month = (int)pred_info[(j*column_num1)+4];
         day=(int)pred_info[(j*column_num1)+5];
         fprintf(prdfile,"%d %f %f %d %d %d %6.4f ",index,pred_info[(j*column_num1)+1],pred_info[(j*column_num1)+2],year,month,day,pred_info[(j*column_num1)+6]);
          fprintf(prdfile, "%6.4f %6.4f\n", mn_pred[j], sqrt(var_pred[j]));

        //Rprintf("%d %d %d %f %f %d %d %d %6.4f\n",j,column_num1, index,pred_info[(j*column_num1)+1],pred_info[(j*column_num1)+2],year,month,day,pred_info[(j*column_num1)+6]);
          //Rprintf("%6.4f %6.4f\n", mn_pred[j], sqrt(var_pred[j]));
     }
     fclose(prdfile); 
     free(mn_pred); free(var_pred); free(iit); 	
     
   Rprintf("crossed bar\n");

     double pen, go;
     pen =0;
     go =0;
     
// pmcc          
     for(j=0; j < N1; j++){
         if (flag[j] == 1.0){
          mn_rep[j] = 0.0;
          var_rep[j] = 0.0;
         }
         else{
          mn_rep[j] = mn_rep[j];
          var_rep[j] = var_rep[j];
          mn_rep[j] = (mn_rep[j] - z[j])*(mn_rep[j] - z[j]);          
         }
         pen += var_rep[j]; 
         go += mn_rep[j];
     }

     penalty[0] = pen;
     gof[0] = go;       
     free(mn_rep); free(var_rep); 

     Rprintf(" ... ");
     Rprintf("\n---------------------------------------------------------\n");   //Rprintf("I can reach at the end\n");
       
     //return;
}


// with all summary values (mean, variance/sd, low2.5, up97.5)
// also the predictions into another sites
// one phi value
// by defalt text output: as big data files
void GIBBS_sumpred_gpp_type(int *aggtype, int *cov, int *spdecay, double *flag, 
     int *its, int *burnin,
     int *n, int *m, int *T, int *r, int *rT, int *p, int *N, int *report,
     double *shape_e, double *shape_eta, double *shape_l,  
     double *phi_a, double *phi_b,
     double *prior_a, double *prior_b, double *mu_beta, double *delta2_beta,
     double *mu_rho,  double *delta2_rho, double *alpha_l, double *delta2_l,
     double *phi, double *tau, double *phis, int *phik,
     double *dm, double *dnm, int *constant, 
     double *sig2e, double *sig2eta, double *sig2l, double *beta, 
     double *rho, double *mu_l, double *X, double *z, double *w0, double *w,
     int *nsite, int *nsiterT, double *Xpred, int *transform, 
     double *accept_f, double *gof, double *penalty, double *cand_coords, int *cand_len, double *data_coords, double *pred_coords, int *pred_len, double *grid_prob, double *knots_sim,
     int *type_fit, int *joint_type, int *len_type_fit, int *len_type_pred, int *predloc, int *name_var)    
{
//     unsigned iseed = 44;
//     srand(iseed); 
     
     int its1, col, i, j, n1, m1, r1, rT1, p1, N1, rep1, nsite1, brin, trans1, effect_size, len_type_fit1, len_type_pred1, N_fit_trim;
     its1 = *its;
     col = *constant;
     n1 = *n;
     m1 = *m;
     r1 = *r;
     rT1 = *rT;
     p1 = *p;
     N1 = *N;
     rep1 = *report;
     nsite1 = *nsite;
     brin = *burnin;
     trans1 = *transform;

     effect_size = its1 - brin;
     len_type_fit1 = *len_type_fit;
     len_type_pred1 = *len_type_pred; 

       double *knots_lon_sim, *knots_lat_sim;
       knots_lon_sim = (double *) malloc((size_t)((m1)*sizeof(double)));
       knots_lat_sim = (double *) malloc((size_t)((m1)*sizeof(double)));  
       for(j=0; j<m1; j++)
       {
         knots_lon_sim[j] = knots_sim[(2*j)+0]; knots_lat_sim[j] = knots_sim[(2*j)+1]; 
         //Rprintf("%f %f\n", knots_lon_sim[j], knots_lat_sim[j]);
       }

     int *size, size1; 
     size = (int *) malloc((size_t)((col)*sizeof(int))); 
     size[0] = (predloc[1] - predloc[0]) + 1;
     size1 = *size;
     N_fit_trim = size1*n1;
     //Rprintf("fit=%d joint=%d\n", N_fit_trim, (size1*nsite1));
       
     double accept1, *mn_rep, *var_rep, *mn_pred, *var_pred, *diff_z_xb, *location, *dnsm, surface_making;
     mn_rep = (double *) malloc((size_t)((N1)*sizeof(double)));          
     var_rep = (double *) malloc((size_t)((N1)*sizeof(double)));          
     mn_pred = (double *) malloc((size_t)((nsite1*rT1)*sizeof(double)));          
     var_pred = (double *) malloc((size_t)((nsite1*rT1)*sizeof(double)));  
     diff_z_xb = (double *) malloc((size_t)((N1)*sizeof(double)));      
     location = (double *) malloc((size_t)((m1)*sizeof(double)));    
     dnsm = (double *) malloc((size_t)((nsite1*m1)*sizeof(double)));  

     accept1 = 0.0;

     for(j=0; j<N1; j++){
        mn_rep[j] = 0.0;
        var_rep[j] = 0.0;
     }      
     for(j=0; j<nsite1*size1; j++){
        mn_pred[j] = 0.0;
        var_pred[j] = 0.0;
     }      

     double *phip, *sig2ep, *sig2etap, *rhop, *betap;
     double *mu_lp, *sig2lp, *wp, *w0p, *zfit, *ofit, *acc;
     phip = (double *) malloc((size_t)((col)*sizeof(double)));          
     sig2ep = (double *) malloc((size_t)((col)*sizeof(double)));
     sig2etap = (double *) malloc((size_t)((col)*sizeof(double)));
     rhop = (double *) malloc((size_t)((col)*sizeof(double)));
     betap = (double *) malloc((size_t)((p1)*sizeof(double)));          
     mu_lp = (double *) malloc((size_t)((r1)*sizeof(double)));    
     sig2lp = (double *) malloc((size_t)((r1)*sizeof(double))); 
     wp = (double *) malloc((size_t)((m1*rT1)*sizeof(double))); 
     w0p = (double *) malloc((size_t)((m1*r1)*sizeof(double))); 
     zfit = (double *) malloc((size_t)((N1)*sizeof(double)));
     ofit = (double *) malloc((size_t)((N1)*sizeof(double)));     
     acc = (double *) malloc((size_t)((col)*sizeof(double)));

     double *phi1, *sig2e1, *sig2eta1, *rho1, *beta1, *w01, *w1;
     phi1 = (double *) malloc((size_t)((col)*sizeof(double)));
     sig2e1 = (double *) malloc((size_t)((col)*sizeof(double)));
     sig2eta1 = (double *) malloc((size_t)((col)*sizeof(double)));
     rho1 = (double *) malloc((size_t)((col)*sizeof(double)));
     beta1 = (double *) malloc((size_t)((p1*col)*sizeof(double)));     
     w01 = (double *) malloc((size_t)((m1*r1)*sizeof(double))); 
     w1 = (double *) malloc((size_t)((m1*rT1)*sizeof(double))); 

     double *zp, *out_fitted; //, *out_prediction, tmp[T1]; , *anf
     double *ave_type_joint, *count_joint;
     //double *ave_type_pred, *count_pred, *ave_type_fit, *count_fit;

     if((predloc[0]==0) & (predloc[1]==(rT1-1))){
       zp = (double *) malloc((size_t)((nsite1*rT1)*sizeof(double)));      
       //anf = (double *) malloc((size_t)((nsite1*r1)*sizeof(double)));     
       //out_prediction = (double *) malloc((size_t)((effect_size*nsite1*rT1)*sizeof(double)));    
       out_fitted = (double *) malloc((size_t)((effect_size*N1)*sizeof(double))); 
       //ave_type_pred = (double *) malloc((size_t)((len_type_pred1)*sizeof(double)));  
       //count_pred = (double *) malloc((size_t)((len_type_pred1)*sizeof(double)));
       //ave_type_fit = (double *) malloc((size_t)((len_type_fit1)*sizeof(double)));     
       //count_fit = (double *) malloc((size_t)((len_type_fit1)*sizeof(double)));    
       ave_type_joint = (double *) malloc((size_t)((len_type_pred1)*sizeof(double)));
       count_joint = (double *) malloc((size_t)((len_type_pred1)*sizeof(double)));     
     }     
  
     if((predloc[0]!=0) | (predloc[1]!=(rT1-1))){
       zp = (double *) malloc((size_t)((nsite1*size1)*sizeof(double)));      
       //anf = (double *) malloc((size_t)((nsite1*r1)*sizeof(double)));     
       //out_prediction = (double *) malloc((size_t)((effect_size*nsite1*rT1)*sizeof(double)));    
       out_fitted = (double *) malloc((size_t)((effect_size*N1)*sizeof(double))); 
       //ave_type_pred = (double *) malloc((size_t)((len_type_pred1)*sizeof(double)));  
       //count_pred = (double *) malloc((size_t)((len_type_pred1)*sizeof(double)));
       //ave_type_fit = (double *) malloc((size_t)((len_type_fit1)*sizeof(double)));     
       //count_fit = (double *) malloc((size_t)((len_type_fit1)*sizeof(double)));    
       ave_type_joint = (double *) malloc((size_t)((len_type_pred1)*sizeof(double)));
       count_joint = (double *) malloc((size_t)((len_type_pred1)*sizeof(double)));     
     }       

     //sd_type_pred = (double *) malloc((size_t)((len_type_pred1)*sizeof(double)));  //, tmp[T1]; , *sd_type_pred, *sd_type_fit
     //sd_type_fit = (double *) malloc((size_t)((len_type_fit1)*sizeof(double)));
     //ave_type_joint = (double *) malloc((size_t)((len_type_pred1)*sizeof(double)));
     //count_joint = (double *) malloc((size_t)((len_type_pred1)*sizeof(double)));            

     double *sample_fit_LA, *sample_pred_LA;
     sample_fit_LA = (double *) malloc((size_t)((effect_size*len_type_fit1)*sizeof(double)));
     sample_pred_LA = (double *) malloc((size_t)((effect_size*len_type_pred1)*sizeof(double)));

     double *nu, *nup;
     nu = (double *) malloc((size_t)((col)*sizeof(double)));
     nup = (double *) malloc((size_t)((col)*sizeof(double)));     
     nu[0] = 0.5;
          
       ext_sige(phi, phi1);
       ext_sige(sig2e, sig2e1);
       ext_sigeta(sig2eta, sig2eta1);
       ext_rho(rho, rho1);
       ext_beta(p, beta, beta1);
       for(j=0; j<m1*rT1; j++){
         w1[j] = w[j];
       }     
       for(j=0; j<m1*r1; j++){
         w01[j] = w0[j];
       }     
       for(j=0; j<len_type_pred1; j++)
       {    
         //count_pred[j]=0;
         count_joint[j]=0;
       }
       /*for(j=0; j<len_type_fit1; j++)
       { 
         count_fit[j]=0;
       }*/
     
     int name_var1, name_var2, name_var3;
     name_var2 = *name_var;    

     if(name_var2<100){
       name_var1 = name_var2/10;  name_var3 = name_var2 % 10;
     }
     if(name_var2>=100){
       name_var1 = name_var2/100;  name_var3 = name_var2 % 100; 
     }
     
     char str2[150], str3[150], str4[150], str5[150], str6[150], str7[150], str8[150], str9[150], str10[10], str11[150]; 
     if(name_var3==1){
       strcpy(str10, "_part1");
     }
     if(name_var3==2){
       strcpy(str10, "_part2");
     }
     if(name_var3==3){
       strcpy(str10, "_part3");
     }
     if(name_var3==4){
       strcpy(str10, "_part4");
     }
     if(name_var3==5){
       strcpy(str10, "_part5");
     }
     if(name_var3==6){
       strcpy(str10, "_part6");
     }
     if(name_var3>=10){
       strcpy(str10, "_part32");
     }

     if(name_var1==1){
       strcpy(str2, "../no2_output/no2");
       strcat(str2, str10);
     }
     if(name_var1==2){
      strcpy(str2, "../ozone_output/ozone");
      strcat(str2, str10); 
     }
     if(name_var1==3){
      strcpy(str2, "../pm10_output/pm10");
      strcat(str2, str10);
     }
     if(name_var1==4){
      strcpy(str2, "../pm2p5_output/pm2p5");
      strcat(str2, str10);
     }
     strcpy(str3, str2);
     strcpy(str4, str2); strcpy(str5, str2); strcpy(str6, str2); strcpy(str7, str2); strcpy(str8, str2); strcpy(str9, str2); strcpy(str11, str2);

     strcat(str2, "OutGPP_Values_Parameter.txt");
     FILE *parafile;
     parafile = fopen(str2, "w");

     FILE *siglfile;
     siglfile = fopen("OutGPP_Values_sigl.txt", "w");
     //FILE *wfile;
     //wfile = fopen("OutGPP_Values_w.txt", "w");

     strcat(str3, "OutGPP_Values_knots.txt");
     FILE *knotfile;
     knotfile = fopen(str3, "w");
     //FILE *difffile;
     //difffile = fopen("OutGPP_Values_diff_z_xb.txt", "w");
     //printf("I have entered the code\n");

     strcat(str4, "OutGPP_Stats_FittedValue.txt");
     printf("strcat( str1, str2):   %s\n", str4 );  
    
     FILE *fitfile;
     fitfile = fopen(str4, "w");
     //FILE *fittedfile;
     //fittedfile = fopen("Fitted_sites_mcmc1.txt", "w");        
  
     //FILE *fittedfile;
     //fittedfile = fopen("Fitted_sites_mcmc1.txt", "w");

     strcat(str5, "OutGPP_Stats_PredValue.txt");
     FILE *prdfile;
     prdfile = fopen(str5, "w");
     //FILE *predfile;
     //predfile = fopen("Prediction_sites_mcmc1.txt", "w");

     strcat(str6, "LA_predicted.txt");
     FILE *lapredfile;
     lapredfile = fopen(str6, "w");

     strcat(str7, "LA_fitted.txt");
     FILE *lafitfile;
     lafitfile = fopen(str7, "w");
     int type1, type_aggrn;
     type1= *aggtype;
     //type_aggrn = *aggrn_type; 
     type_aggrn = 1;

     strcat(str8, "Summary_joint_LA.txt");
     FILE *texttype1;
     texttype1 = fopen(str8, "w");

     strcat(str11, "Prediction_LA_limits.txt");
     FILE *summaryLApredfile;
     summaryLApredfile = fopen(str11, "w");
     
   
     /*FILE *textan;
     // none
     if(type1==0){
       textan = fopen("OutGPP_NONE.txt", "w");
     }
     // annual average value
     if(type1==1){
       textan = fopen("OutGPP_Annual_Average_Prediction.txt", "w");
     }
     // annual 4th highest value
     if(type1==2){
       textan = fopen("OutGPP_Annual_4th_Highest_Prediction.txt", "w");
     }
     // annual w126 option
     if(type1==3){
       textan = fopen("OutGPP_Annual_w126_Prediction.txt", "w");
     }*/

     for(j=0; j<m1; j++)
     {
       location[j]=-2.0;
     }

     /*for(j=0; j<N_fit_trim; j++)
     {
       if(type_fit[j]>=0)
       {
         count_fit[type_fit[j]] = count_fit[type_fit[j]] + 1;
       } 
     }*/
     /*for(j=0; j<(nsite1*rT1); j++)
     {
       count_pred[type_pred[j]] = count_pred[type_pred[j]] + 1;
     }*/
     for(j=0; j<(N_fit_trim+(nsite1*size1)); j++)
     {
       if(joint_type[j]>=0)
       {
         count_joint[joint_type[j]] = count_joint[joint_type[j]] + 1;
       }     
     }
   
     /*int *size, size1; 
     double *wpt;
     size = (int *) malloc((size_t)((col)*sizeof(int))); 
     size[0] = (rT1 - posT1);
     size1 = *size;
     wpt = (double *) malloc((size_t)((m1*size1)*sizeof(double)));*/

     geo_dist_cross(pred_len, m, pred_coords, knots_lat_sim, knots_lon_sim, dnsm);  

     GetRNGstate();            
     for(i=0; i < its1; i++) {

     JOINT_onephi_gpp_ran(cov, spdecay, flag, n, m, T, r, rT, p, N, 
     shape_e, shape_eta, shape_l, 
     phi_a, phi_b,
     prior_a, prior_b, mu_beta, delta2_beta, 
     mu_rho, delta2_rho, alpha_l, delta2_l, phi1, tau, phis, phik, nu, dm, dnm, dnsm,
     constant, sig2e1, sig2eta1, sig2l, beta1, rho1, mu_l, X, z, w01, w1, 
     phip, acc, nup, sig2ep, sig2etap, betap, rhop, mu_lp, sig2lp, w0p, wp, zfit, diff_z_xb, cand_coords, cand_len, data_coords, pred_coords, pred_len, grid_prob, knots_lon_sim, knots_lat_sim,
     location);  

     /*if(i >= brin){
     for(j=(posT1*m1); j<(rT1*m1); j++)
     {
       wpt[j - (posT1*m1)] = wp[j];
       fprintf(difffile, "%f ", wpt[j - (posT1*m1)]);
     } 
     fprintf(difffile, "\n");  
     for(j=0; j < m1*rT1; j++){
     fprintf(wfile, "%f ", wp[j]);
     }
     fprintf(wfile, "\n");  
     }*/

     if((predloc[0]==0) & (predloc[1]==(rT1-1))){
       z_pr_gpp1(cov, nsite, n, m, r, T, rT, p, nsiterT, phip, nup, dm, dnsm, 
       wp, sig2ep, betap, Xpred, constant, zp);
     }
     if((predloc[0]!=0) | (predloc[1]!=(rT1-1))){
       z_pr_gpp1_mod(cov, nsite, n, m, r, T, rT, p, nsiterT, phip, nup, dm, dnsm, 
       wp, sig2ep, betap, Xpred, constant, zp, predloc);
     }

     accept1 += acc[0];

     for(j=0; j < p1; j++){
     fprintf(parafile, "%f ", betap[j]);
     }         
     fprintf(parafile, "%f ", rhop[0]);
     fprintf(parafile, "%f ", sig2ep[0]);
     fprintf(parafile, "%f ", sig2etap[0]);
     fprintf(parafile, "%f ", phip[0]);
     if(cov[0]==4){
      fprintf(parafile, "%f ", nup[0]);
     }     
     fprintf(parafile, "\n");

     for(j=0; j<m1; j++)
     {
       fprintf(knotfile, "%f %f ", knots_lon_sim[j], knots_lat_sim[j]);
     }
     fprintf(knotfile, "\n");   
     /*for(j=0; j < r1; j++){
     fprintf(siglfile, "%f\n", sig2lp[j]);
     }
     for(j=0; j < m1*r1; j++){
     fprintf(w0file, "%f ", w0p[j]);
     }
     fprintf(w0file, "\n");    
     for(j=0; j < N1; j++)
     {
       fprintf(difffile, "%f\n", diff_z_xb[j]);
     }
     fprintf(difffile, "\n");*/

       for(j=0; j<len_type_pred1; j++)
       {
         //ave_type_pred[j]=0; 
         ave_type_joint[j]=0;
       }
       /*for(j=0; j<len_type_fit1; j++)
       {
         ave_type_fit[j]=0;  
       }*/

// for pmcc, fitted sum values    
     for(j=0; j < N1; j++){
         if(i >= brin){  
          mn_rep[j] += zfit[j];
          var_rep[j] += zfit[j]*zfit[j];
         } 
     }
     
     int mark, pcount;
     mark=0; pcount=0;
     if(i >= brin){
        for(j=0; j<N1; j++){
            if(trans1 == 0){
             out_fitted[((i-brin)*N1)+j] = zfit[j];
            }
           if(trans1 == 1){
             out_fitted[((i-brin)*N1)+j] = zfit[j]*zfit[j];
           }
           if(trans1 == 2){
             out_fitted[((i-brin)*N1)+j] = exp(zfit[j]); 
           }
           if((j >= ((mark*rT1) + predloc[0])) && (j <= ((mark*rT1) + predloc[1]))){
             if((type_fit[pcount]>=0) && (joint_type[pcount]>=0))
             {
               //ave_type_fit[type_fit[pcount]] = ave_type_fit[type_fit[pcount]] + out_fitted[((i-brin)*N1)+j];    
               ave_type_joint[joint_type[pcount]] = ave_type_joint[joint_type[pcount]] + out_fitted[((i-brin)*N1)+j];        
               pcount = pcount+1;          
             }  
           }
           if(pcount==((mark+1)*(predloc[1]-predloc[0]+1)))
           {
             mark=mark+1;
           }    
         }
     }

// prediction samples
     if(i >= brin){
     for(j=0; j<(nsite1*size1); j++){
         if(trans1 == 0){
           zp[j] = zp[j];
           //fprintf(predfile, "%f ", zp[j]);
         }
         if(trans1 == 1){
           zp[j] = zp[j]*zp[j];
           //fprintf(predfile, "%f ", zp[j]);
         }
         if(trans1 == 2){
           zp[j] = exp(zp[j]);
           //fprintf(predfile, "%f ", zp[j]);
         }

         //out_prediction[((i-brin)*nsite1*rT1)+j] = zp[j]; 
         //ave_type_pred[type_pred[j]]=ave_type_pred[type_pred[j]]+zp[j]; 
         if((joint_type[N_fit_trim+j]>=0)){
           ave_type_joint[joint_type[N_fit_trim+j]] = ave_type_joint[joint_type[N_fit_trim+j]] + zp[j]; 
         }
     }                            
     //fprintf(predfile, "\n");

     }	

     if(i >= brin){
       for(j=0; j<len_type_pred1; j++)
       {
         //ave_type_pred[j]=ave_type_pred[j]/(double)count_pred[j]; 
         //fprintf(lapredfile, "%f ", ave_type_pred[j]); 
         if(count_joint[j]>0)
         {
           ave_type_joint[j] = ave_type_joint[j]/(double)count_joint[j];
           fprintf(texttype1, "%f ", ave_type_joint[j]); 
         }
           if(type_aggrn==1)
           {
             sample_pred_LA[((i-brin)*len_type_pred1)+j] = ave_type_joint[j];
           }           
         
       }
       //fprintf(lapredfile, "\n"); 
       if(count_joint[j]>0){
       fprintf(texttype1, "\n"); 
       }

       /*for(j=0; j<len_type_fit1; j++)
       {
         if(count_fit[j]>0)
         {
           ave_type_fit[j]=ave_type_fit[j]/(double)count_fit[j];  
           fprintf(lafitfile, "%f ", ave_type_fit[j]); 
         }
           if(type_aggrn==1)
           {
             sample_fit_LA[((i-brin)*len_type_fit1)+j] = ave_type_fit[j];
           }       
       }
       if(count_fit[j]>0){
       fprintf(lafitfile, "\n"); 
       }*/

     }
     
   
// prediction samples summary
     for(j=0; j<(nsite1*size1); j++){
         if(i >= brin){  
          mn_pred[j] += zp[j];
          var_pred[j] += zp[j]*zp[j];
         }
     }

       ext_sige(phip, phi1);
       ext_sige(sig2ep, sig2e1);
       ext_sigeta(sig2etap, sig2eta1); 
       ext_rho(rhop, rho1); 
       ext_beta(p, betap, beta1);              
       for(j=0; j<m1*rT1; j++){
         w1[j] = wp[j];
       }     
       for(j=0; j<m1*r1; j++){
         w01[j] = w0p[j];
       }     

     if(cov[0]==4){
     para_printRnu (i, its1, rep1, p1, accept1, phip, nup, rhop, sig2ep, sig2etap, betap); 
     }                   
     else {              
     para_printR (i, its1, rep1, p1, accept1, phip, rhop, sig2ep, sig2etap, betap); 
     }
      if(i >= brin){
         /*if(posT1==0){
         annual_aggregate_uneqT(aggtype, nsite, r, T, rT, zp, anf);
//         annual_aggregate(aggtype, nsite, r, T, zp, anf);
  	     for(j=0; j<(nsite1*r1); j++){
           fprintf(textan, "%f ", anf[j]);
         }
         fprintf(textan, "\n");
         }
         if(posT1!=0){
         annual_aggregate_trim_uneqT(aggtype, nsite, r, T, size, zp, anf);
//         annual_aggregate(aggtype, nsite, r, T, zp, anf);
  	     for(j=0; j<(nsite1*r1); j++){
           fprintf(textan, "%f ", anf[j]);
         }
         fprintf(textan, "\n");
         } */
/*
       // annual average value
       if(type1==1){
         annual_aggregate(aggtype, nsite, r, T, zp, anf);
  	     for(j=0; j<(nsite1*r1); j++){
           fprintf(textan, "%f ", anf[j]);
         }
         fprintf(textan, "\n");
       }
       // annual 4th highest value
       if(type1==2){
         annual_aggregate(aggtype, nsite, r, T, zp, anf);
  	     for(j=0; j<(nsite1*r1); j++){
           fprintf(textan, "%f ", anf[j]);
         }
         fprintf(textan, "\n");
       }     
       // annual w126 
       if(type1==3){
         annual_aggregate(aggtype, nsite, r, T, zp, anf);
  	     for(j=0; j<(nsite1*r1); j++){
           fprintf(textan, "%f ", anf[j]);
         }
         fprintf(textan, "\n");
       }     
*/
      } // end of loop i >= brin
     } // end of iteration loop
     free(dnsm);  
       
     //FILE *summaryfile;
     //summaryfile = fopen("Prediction_sites_summary.txt", "w");
     FILE *summaryfitfile;
     summaryfitfile = fopen("Fitted_sites_summary.txt", "w");
     // Producing summary
     double *x, u_mean, v_var, lcl, ucl;
 
     x = malloc( effect_size* sizeof(double) ); 
 
     /*for (j=0; j<(nsite1*rT1); j++) {
      for (i=0; i<effect_size; i++) {
          x[i] = out_prediction[i*(nsite1*rT1)+j];
          }
          sort_values(x, effect_size);
          mean_var(x, effect_size, &u_mean, &v_var);
          v_var = sqrt(v_var);
          i = effect_size * 0.025;
          lcl = x[i];
          i = effect_size * 0.975;
          ucl = x[i];
          
         fprintf(summaryfile,"%f  %f  %f  %f\n", u_mean, v_var, lcl, ucl);
     }
     fclose(summaryfile); */

     for (j=0; j<N1; j++) {
      for (i=0; i<effect_size; i++) {
          x[i] = out_fitted[(i*N1)+j];
          }
          sort_values(x, effect_size);
          mean_var(x, effect_size, &u_mean, &v_var);
          v_var = sqrt(v_var);
          i = effect_size * 0.025;
          lcl = x[i];
          i = effect_size * 0.975;
          ucl = x[i];
          
         fprintf(summaryfitfile,"%f  %f  %f  %f\n", u_mean, v_var, lcl, ucl);
     }
      fclose(summaryfitfile); 

     FILE *summaryLAfitfile;
     summaryLAfitfile = fopen("Fitted_LA_limits.txt", "w");
     if(type_aggrn==1)
     {
       for (j=0; j<len_type_pred1; j++) {
       for (i=0; i<effect_size; i++) {
          x[i] = sample_pred_LA[(i*len_type_pred1)+j];
          }
          sort_values(x, effect_size);
          
          mean_var(x, effect_size, &u_mean, &v_var);
          v_var = sqrt(v_var);
          i = effect_size * 0.025;
          lcl = x[i];
          i = effect_size * 0.975;
          ucl = x[i];
          
         fprintf(summaryLApredfile,"%f  %f  %f  %f\n", u_mean, v_var, lcl, ucl);
       }

       /*for (j=0; j<len_type_fit1; j++) {
       for (i=0; i<effect_size; i++) {
          x[i] = sample_fit_LA[(i*len_type_fit1)+j];
          }          
          sort_values(x, effect_size);
         
          mean_var(x, effect_size, &u_mean, &v_var);
          v_var = sqrt(v_var);
          i = effect_size * 0.025;
          lcl = x[i];
          i = effect_size * 0.975;
          ucl = x[i];
          
         fprintf(summaryLAfitfile,"%f  %f  %f  %f\n", u_mean, v_var, lcl, ucl);
       }*/
     }

     free(x);     
     fclose(summaryLApredfile);   fclose(summaryLAfitfile);

     /*for(j=0; j<len_type_fit1; j++)
     {
       if(count_fit[j]!=0)
       {
         ave_type_fit[j] = ave_type_fit[j]/((double)(count_fit[j]));
         sd_type_fit[j] = (sd_type_fit[j]/((double)(count_fit[j]))) - (ave_type_fit[j]*ave_type_fit[j]);
       }  
       fprintf(lafitfile, "%f %f\n", ave_type_fit[j], sqrt(sd_type_fit[j])); 
     }

     for(j=0; j<len_type_pred1; j++)
     {
       if(count_pred[j]!=0)
       {
         ave_type_pred[j] = ave_type_pred[j]/((double)(count_pred[j]*effect_size));
         sd_type_pred[j] = (sd_type_pred[j]/((double)(count_pred[j]*effect_size))) - (ave_type_pred[j]*ave_type_pred[j]);
       }   
       fprintf(lapredfile, "%f %f\n", ave_type_pred[j], sqrt(sd_type_pred[j])); 
     }*/
     
     PutRNGstate();

     fclose(parafile);
     //fclose(predfile);
     //fclose(fittedfile); 
     //fclose(textan);
     fclose(siglfile);
     fclose(knotfile);
     //fclose(wfile);
     //fclose(difffile);
     fclose(lafitfile);
     fclose(lapredfile);
     fclose(texttype1);
    
     free(size); //free(wpt);

    free(phip); free(sig2ep); free(sig2etap); free(rhop); free(betap); free(location); free(out_fitted);  //free(out_prediction); 
    free(mu_lp); free(sig2lp); free(wp); free(w0p); free(zfit); free(ofit); free(knots_lon_sim); free(knots_lat_sim); 
    free(acc); 
    free(phi1); free(sig2e1); free(sig2eta1); free(rho1); free(beta1);
    free(zp); free(diff_z_xb); 
    free(ave_type_joint); free(count_joint);
    //free(ave_type_pred); free(count_pred); free(anf);  
    //free(ave_type_fit); free(count_fit); 
    free(sample_pred_LA); free(sample_fit_LA);  

     Rprintf(" Calculating Summary Statistics \n ... ");

     accept_f[0] = accept1;

//     int iit;
//     iit = 0;
//     iit = its1 - brin;

	int *iit;
    iit = (int *) malloc((size_t)((col)*sizeof(int)));
	iit[0] = its[0] - burnin[0];

// fitted zlt, mean and sd
     for(j=0; j < N1; j++){
          mn_rep[j] = mn_rep[j]/iit[0];
          var_rep[j] = var_rep[j]/iit[0];
          surface_making = var_rep[j];
          var_rep[j] = var_rep[j] - mn_rep[j]*mn_rep[j];
          fprintf(fitfile, "%f , %f \n", surface_making, sqrt(var_rep[j]));
     }
     fclose(fitfile);

// pred mean and sd
     for(j=0; j < (nsite1*size1); j++){
          mn_pred[j] = mn_pred[j]/iit[0];
          var_pred[j] = var_pred[j]/iit[0];
          var_pred[j] = var_pred[j] - mn_pred[j]*mn_pred[j];
          fprintf(prdfile, "%f , %f \n", mn_pred[j], sqrt(var_pred[j]));
     }
     fclose(prdfile); 
     free(mn_pred); free(var_pred); free(iit); 	
     
   

     double pen, go;
     pen =0;
     go =0;
     
// pmcc          
     for(j=0; j < N1; j++){
         if (flag[j] == 1.0){
          mn_rep[j] = 0.0;
          var_rep[j] = 0.0;
         }
         else{
          mn_rep[j] = mn_rep[j];
          var_rep[j] = var_rep[j];
          mn_rep[j] = (mn_rep[j] - z[j])*(mn_rep[j] - z[j]);          
         }
         pen += var_rep[j]; 
         go += mn_rep[j];
     }

     penalty[0] = pen;
     gof[0] = go;       
     free(mn_rep); free(var_rep); 

     Rprintf(" ... ");
     Rprintf("\n---------------------------------------------------------\n");
       
     return;
}

void GIBBS_sumpred_gpp_any(int *aggtype, int *cov, int *spdecay, double *flag, 
     int *its, int *burnin,
     int *n, int *m, int *T, int *r, int *rT, int *p, int *N, int *report,
     double *shape_e, double *shape_eta, double *shape_l,  
     double *phi_a, double *phi_b,
     double *prior_a, double *prior_b, double *mu_beta, double *delta2_beta,
     double *mu_rho,  double *delta2_rho, double *alpha_l, double *delta2_l,
     double *phi, double *tau, double *phis, int *phik,
     double *dm, double *dnm, int *constant, 
     double *sig2e, double *sig2eta, double *sig2l, double *beta, 
     double *rho, double *mu_l, double *X, double *z, double *w0, double *w,
     int *nsite, int *nsiterT, double *Xpred, int *transform, 
     double *accept_f, double *gof, double *penalty, double *cand_coords, int *cand_len, double *data_coords, double *pred_coords, int *pred_len, double *grid_prob, double *knots_lon_sim,
     double *knots_lat_sim, int *predloc)    
{
//     unsigned iseed = 44;
//     srand(iseed); 
     
     int its1, col, i, j, n1, m1, r1, rT1, p1, N1, rep1, nsite1, brin, trans1, effect_size;
     its1 = *its;
     col = *constant;
     n1 = *n;
     m1 = *m;
     r1 = *r;
     rT1 = *rT;
     p1 = *p;
     N1 = *N;
     rep1 = *report;
     nsite1 = *nsite;
     brin = *burnin;
     trans1 = *transform;

     effect_size = its1 - brin;

     int *size, size1; 
     size = (int *) malloc((size_t)((col)*sizeof(int))); 
     size[0] = (predloc[1] - predloc[0]) + 1;
     size1 = *size;
     
     double accept1, *mn_rep, *var_rep, *mn_pred, *var_pred, *diff_z_xb, *location, *dnsm, surface_making;
     mn_rep = (double *) malloc((size_t)((N1)*sizeof(double)));          
     var_rep = (double *) malloc((size_t)((N1)*sizeof(double)));          
     mn_pred = (double *) malloc((size_t)((nsite1*rT1)*sizeof(double)));          
     var_pred = (double *) malloc((size_t)((nsite1*rT1)*sizeof(double)));  
     diff_z_xb = (double *) malloc((size_t)((N1)*sizeof(double)));      
     location = (double *) malloc((size_t)((m1)*sizeof(double)));  
     dnsm = (double *) malloc((size_t)((nsite1*m1)*sizeof(double)));            

     accept1 = 0.0;

     for(j=0; j<N1; j++){
        mn_rep[j] = 0.0;
        var_rep[j] = 0.0;
     }      
     for(j=0; j<nsite1*rT1; j++){
        mn_pred[j] = 0.0;
        var_pred[j] = 0.0;
     }      

     double *phip, *sig2ep, *sig2etap, *rhop, *betap;
     double *mu_lp, *sig2lp, *wp, *w0p, *zfit, *ofit, *acc;
     phip = (double *) malloc((size_t)((col)*sizeof(double)));          
     sig2ep = (double *) malloc((size_t)((col)*sizeof(double)));
     sig2etap = (double *) malloc((size_t)((col)*sizeof(double)));
     rhop = (double *) malloc((size_t)((col)*sizeof(double)));
     betap = (double *) malloc((size_t)((p1)*sizeof(double)));          
     mu_lp = (double *) malloc((size_t)((r1)*sizeof(double)));    
     sig2lp = (double *) malloc((size_t)((r1)*sizeof(double))); 
     wp = (double *) malloc((size_t)((m1*rT1)*sizeof(double))); 
     w0p = (double *) malloc((size_t)((m1*r1)*sizeof(double))); 
     zfit = (double *) malloc((size_t)((N1)*sizeof(double)));
     ofit = (double *) malloc((size_t)((N1)*sizeof(double)));     
     acc = (double *) malloc((size_t)((col)*sizeof(double)));

     double *phi1, *sig2e1, *sig2eta1, *rho1, *beta1, *w01, *w1;
     phi1 = (double *) malloc((size_t)((col)*sizeof(double)));
     sig2e1 = (double *) malloc((size_t)((col)*sizeof(double)));
     sig2eta1 = (double *) malloc((size_t)((col)*sizeof(double)));
     rho1 = (double *) malloc((size_t)((col)*sizeof(double)));
     beta1 = (double *) malloc((size_t)((p1*col)*sizeof(double)));     
     w01 = (double *) malloc((size_t)((m1*r1)*sizeof(double))); 
     w1 = (double *) malloc((size_t)((m1*rT1)*sizeof(double))); 

     double *zp, *anf, *out_prediction, *out_fitted; //, tmp[T1];
     zp = (double *) malloc((size_t)((nsite1*rT1)*sizeof(double)));      
     anf = (double *) malloc((size_t)((nsite1*r1)*sizeof(double)));     
     out_prediction = (double *) malloc((size_t)((effect_size*nsite1*rT1)*sizeof(double)));    
     out_fitted = (double *) malloc((size_t)((effect_size*N1)*sizeof(double)));    

     double *nu, *nup;
     nu = (double *) malloc((size_t)((col)*sizeof(double)));
     nup = (double *) malloc((size_t)((col)*sizeof(double)));     
     nu[0] = 0.5;
          
       ext_sige(phi, phi1);
       ext_sige(sig2e, sig2e1);
       ext_sigeta(sig2eta, sig2eta1);
       ext_rho(rho, rho1);
       ext_beta(p, beta, beta1);
       for(j=0; j<m1*rT1; j++){
         w1[j] = w[j];
       }     
       for(j=0; j<m1*r1; j++){
         w01[j] = w0[j];
       }     

     FILE *parafile;
     parafile = fopen("OutGPP_Values_Parameter.txt", "w");
     FILE *siglfile;
     siglfile = fopen("OutGPP_Values_sigl.txt", "w");
     FILE *wfile;
     wfile = fopen("OutGPP_Values_w.txt", "w");
     FILE *knotfile;
     knotfile = fopen("OutGPP_Values_knots.txt", "w");
     FILE *difffile;
     difffile = fopen("OutGPP_Values_diff_z_xb.txt", "w");
     FILE *fitfile;
     fitfile = fopen("OutGPP_Stats_FittedValue.txt", "w");
     FILE *fittedfile;
     fittedfile = fopen("Fitted_sites_mcmc1.txt", "w");
     FILE *prdfile;
     prdfile = fopen("OutGPP_Stats_PredValue.txt", "w");
     //FILE *predfile;
     //predfile = fopen("Prediction_sites_mcmc1.txt", "w");

     int type1;
     type1= *aggtype;
   
     FILE *textan;
     // none
     if(type1==0){
       textan = fopen("OutGPP_NONE.txt", "w");
     }
     // annual average value
     if(type1==1){
       textan = fopen("OutGPP_Annual_Average_Prediction.txt", "w");
     }
     // annual 4th highest value
     if(type1==2){
       textan = fopen("OutGPP_Annual_4th_Highest_Prediction.txt", "w");
     }
     // annual w126 option
     if(type1==3){
       textan = fopen("OutGPP_Annual_w126_Prediction.txt", "w");
     }

     for(j=0; j<m1; j++)
     {
       location[j]=-2.0;
     }
    
     geo_dist_cross(pred_len, m, pred_coords, knots_lat_sim, knots_lon_sim, dnsm);  
     
     GetRNGstate();            
     for(i=0; i < its1; i++) {

     JOINT_onephi_gpp_ran(cov, spdecay, flag, n, m, T, r, rT, p, N, 
     shape_e, shape_eta, shape_l, 
     phi_a, phi_b,
     prior_a, prior_b, mu_beta, delta2_beta, 
     mu_rho, delta2_rho, alpha_l, delta2_l, phi1, tau, phis, phik, nu, dm, dnm, dnsm,
     constant, sig2e1, sig2eta1, sig2l, beta1, rho1, mu_l, X, z, w01, w1, 
     phip, acc, nup, sig2ep, sig2etap, betap, rhop, mu_lp, sig2lp, w0p, wp, zfit, diff_z_xb, cand_coords, cand_len, data_coords, pred_coords, pred_len, grid_prob, knots_lon_sim, knots_lat_sim,
     location);  

     //z_pr_gpp1(cov, nsite, n, m, r, T, rT, p, nsiterT, phip, nup, dm, dnsm, 
     //wp, sig2ep, betap, Xpred, constant, zp);
     if((predloc[0]==0) & (predloc[1]==(rT1-1))){
       z_pr_gpp1(cov, nsite, n, m, r, T, rT, p, nsiterT, phip, nup, dm, dnsm, 
       wp, sig2ep, betap, Xpred, constant, zp);
     }
     if((predloc[0]!=0) | (predloc[1]!=(rT1-1))){
       z_pr_gpp1_mod(cov, nsite, n, m, r, T, rT, p, nsiterT, phip, nup, dm, dnsm, 
       wp, sig2ep, betap, Xpred, constant, zp, predloc);
     }


     accept1 += acc[0];

     for(j=0; j < p1; j++){
     fprintf(parafile, "%f ", betap[j]);
     }         
     fprintf(parafile, "%f ", rhop[0]);
     fprintf(parafile, "%f ", sig2ep[0]);
     fprintf(parafile, "%f ", sig2etap[0]);
     fprintf(parafile, "%f ", phip[0]);
     if(cov[0]==4){
      fprintf(parafile, "%f ", nup[0]);
     }     
     fprintf(parafile, "\n");

     for(j=0; j<m1; j++)
     {
       fprintf(knotfile, "%f %f ", knots_lon_sim[j], knots_lat_sim[j]);
     }
     fprintf(knotfile, "\n");   
     /*for(j=0; j < r1; j++){
     fprintf(siglfile, "%f\n", sig2lp[j]);
     }
     for(j=0; j < m1*r1; j++){
     fprintf(w0file, "%f ", w0p[j]);
     }
     fprintf(w0file, "\n");
     for(j=0; j < m1*rT1; j++){
     fprintf(wfile, "%f ", wp[j]);
     }
     fprintf(wfile, "\n");
     for(j=0; j < N1; j++)
     {
       fprintf(difffile, "%f\n", diff_z_xb[j]);
     }
     fprintf(difffile, "\n");*/
// for pmcc, fitted sum values    
     for(j=0; j < N1; j++){
         if(i >= brin){  
          mn_rep[j] += zfit[j];
          var_rep[j] += zfit[j]*zfit[j];
         } 
     }

     if(i >= brin){
        for(j=0; j<N1; j++){
            if(trans1 == 0){
             out_fitted[((i-brin)*N1)+j] = zfit[j];
            }
           if(trans1 == 1){
             out_fitted[((i-brin)*N1)+j] = zfit[j]*zfit[j];
           }
           if(trans1 == 2){
             out_fitted[((i-brin)*N1)+j] = exp(zfit[j]); 
           }
         }
     }

// prediction samples
     if(i >= brin){
     for(j=0; j<(nsite1*size1); j++){
         if(trans1 == 0){
           zp[j] = zp[j];
           //fprintf(predfile, "%f ", zp[j]);
         }
         if(trans1 == 1){
           zp[j] = zp[j]*zp[j];
           //fprintf(predfile, "%f ", zp[j]);
         }
         if(trans1 == 2){
           zp[j] = exp(zp[j]);
           //fprintf(predfile, "%f ", zp[j]);
         }

         out_prediction[((i-brin)*nsite1*rT1)+j] = zp[j]; 
     }                            
     //fprintf(predfile, "\n");

     }	

// prediction samples summary
     for(j=0; j<(nsite1*size1); j++){
         if(i >= brin){  
          mn_pred[j] += zp[j];
          var_pred[j] += zp[j]*zp[j];
         }
     }

       ext_sige(phip, phi1);
       ext_sige(sig2ep, sig2e1);
       ext_sigeta(sig2etap, sig2eta1); 
       ext_rho(rhop, rho1); 
       ext_beta(p, betap, beta1);              
       for(j=0; j<m1*rT1; j++){
         w1[j] = wp[j];
       }     
       for(j=0; j<m1*r1; j++){
         w01[j] = w0p[j];
       }     

     if(cov[0]==4){
     para_printRnu (i, its1, rep1, p1, accept1, phip, nup, rhop, sig2ep, sig2etap, betap); 
     }                   
     else {              
     para_printR (i, its1, rep1, p1, accept1, phip, rhop, sig2ep, sig2etap, betap); 
     }

      if(i >= brin){
         annual_aggregate_uneqT(aggtype, nsite, r, T, rT, zp, anf);
//         annual_aggregate(aggtype, nsite, r, T, zp, anf);
  	     for(j=0; j<(nsite1*r1); j++){
           fprintf(textan, "%f ", anf[j]);
         }
         fprintf(textan, "\n");

      } // end of loop i >= brin
     } // end of iteration loop
     free(dnsm);

       int k1, half_sample; 
       if(effect_size <= 2000)
       {
         for(j=0; j<effect_size; j++)
         {
           //fprintf(predfile, "itr%d ", j+1);
  
           fprintf(fittedfile, "itr%d ", j+1);
         } 
      
         //fprintf(predfile, "\n");
         fprintf(fittedfile, "\n");

         /*for(j=0; j<nsite1; j++)
         {
           for(k1=0; k1<rT1; k1++)
           {
             fprintf(predfile, "s%dt%d ",j+1,k1+1);
             for(i=0; i<effect_size; i++)
             {
               fprintf(predfile, "%f ", out_prediction[(i*nsite1*rT1)+(j*rT1)+k1]);
             }
             fprintf(predfile, "\n");
           }
         }*/

         for(j=0; j<N1; j++)
         {
           for(i=0; i<effect_size; i++)
           {
             fprintf(fittedfile, "%f ", out_fitted[(i*N1)+j]);
           }
           fprintf(fittedfile, "\n");
         }
       }
       

     if(effect_size > 2000)
     {
       //FILE *predfile_half;
       //predfile_half = fopen("Prediction_sites_mcmc2.txt", "w");
       FILE *fittedfile_half;
       fittedfile_half = fopen("Fitted_sites_mcmc2.txt", "w");

       half_sample = (int)(effect_size/2);
       for(j=0; j<half_sample; j++)
       {
         //fprintf(predfile, "itr%d ", j+1);
         fprintf(fittedfile, "itr%d ", j+1);
         //fprintf(predfile_half, "itr%d ", (half_sample+j+1));    
         fprintf(fittedfile_half, "itr%d ", (half_sample+j+1));    
       } 
       //fprintf(predfile, "\n");
       fprintf(fittedfile, "\n");
       //fprintf(predfile_half, "\n");
       fprintf(fittedfile_half, "\n");
       
       /*for(j=0; j<nsite1; j++)
       {
          for(k1=0; k1<rT1; k1++)
          {
            fprintf(predfile, "s%dt%d ",j+1,k1+1);
            fprintf(predfile_half, "s%dt%d ",(half_sample+j+1), (k1+1));
            for(i=0; i<half_sample; i++)
            {
              fprintf(predfile, "%f ", out_prediction[(i*nsite1*rT1)+(j*rT1)+k1]);
              fprintf(predfile_half, "%f ", out_prediction[((i+half_sample)*nsite1*rT1)+(j*rT1)+k1]);
            }
            fprintf(predfile, "\n");
            fprintf(predfile_half, "\n");
          }
       }*/

        for(j=0; j<N1; j++)
        {
          for(i=0; i<half_sample; i++)
          {
            fprintf(fittedfile, "%f ", out_fitted[(i*N1)+j]);
            fprintf(fittedfile_half, "%f ", out_fitted[((i+half_sample)*N1)+j]);
          }
          fprintf(fittedfile, "\n");
          fprintf(fittedfile_half, "\n");
        }
        //fclose(predfile_half);  
        fclose(fittedfile_half); 
     } 


     FILE *summaryfile;
     summaryfile = fopen("Prediction_sites_summary.txt", "w");
     FILE *summaryfitfile;
     summaryfitfile = fopen("Fitted_sites_summary.txt", "w");
     // Producing summary
     double *x, u_mean, v_var, lcl, ucl;
 
     x = malloc( effect_size* sizeof(double) ); 
 
     for (j=0; j<(nsite1*size1); j++) {
      for (i=0; i<effect_size; i++) {
          x[i] = out_prediction[i*(nsite1*rT1)+j];
          }
          //qsort(x, (int)effect_size, sizeof(int), cmpfunc);
          sort_values(x, effect_size);
          /*for (i=0; i<effect_size; i++) {
          fprintf(summaryfile,"%f ", x[i]);
          }
          fprintf(summaryfile,"\n"); */
          mean_var(x, effect_size, &u_mean, &v_var);
          v_var = sqrt(v_var);
          i = effect_size * 0.025;
          lcl = x[i];
          i = effect_size * 0.975;
          ucl = x[i];
          
         fprintf(summaryfile,"%f  %f  %f  %f\n", u_mean, v_var, lcl, ucl);
         //Rprintf("effect_size= %d\n",effect_size);
         //fprintf(summaryfile,"%4.4f  %4.4f\n", lcl, ucl);
     }

     for (j=0; j<N1; j++) {
      for (i=0; i<effect_size; i++) {
          x[i] = out_fitted[(i*N1)+j];
          }
          //qsort(x, (int)effect_size, sizeof(int), cmpfunc);
          sort_values(x, effect_size);
          /*for (i=0; i<effect_size; i++) {
          fprintf(summaryfile,"%f ", x[i]);
          }
          fprintf(summaryfile,"\n"); */
          mean_var(x, effect_size, &u_mean, &v_var);
          v_var = sqrt(v_var);
          i = effect_size * 0.025;
          lcl = x[i];
          i = effect_size * 0.975;
          ucl = x[i];
          
         fprintf(summaryfitfile,"%f  %f  %f  %f\n", u_mean, v_var, lcl, ucl);
         //Rprintf("effect_size= %d\n",effect_size);
         //fprintf(summaryfile,"%4.4f  %4.4f\n", lcl, ucl);
     }
     
     free(x);
     fclose(summaryfile); fclose(summaryfitfile); 

     
     PutRNGstate();

     fclose(parafile);
     //fclose(predfile);
     fclose(fittedfile); 
     fclose(textan);
     fclose(siglfile);
     fclose(knotfile);
     fclose(wfile);
     fclose(difffile);
     

    free(phip); free(sig2ep); free(sig2etap); free(rhop); free(betap); free(location);  free(out_prediction); free(out_fitted); 
    free(mu_lp); free(sig2lp); free(wp); free(w0p); free(zfit); free(ofit); 
    free(acc); 
    free(phi1); free(sig2e1); free(sig2eta1); free(rho1); free(beta1);
    free(zp); free(anf); free(diff_z_xb);  

     Rprintf(" Calculating Summary Statistics \n ... ");

     accept_f[0] = accept1;

//     int iit;
//     iit = 0;
//     iit = its1 - brin;

	int *iit;
    iit = (int *) malloc((size_t)((col)*sizeof(int)));
	iit[0] = its[0] - burnin[0];

// fitted zlt, mean and sd
     for(j=0; j < N1; j++){
          mn_rep[j] = mn_rep[j]/iit[0];
          var_rep[j] = var_rep[j]/iit[0];
          surface_making = var_rep[j];
          var_rep[j] = var_rep[j] - mn_rep[j]*mn_rep[j];
          fprintf(fitfile, "%f , %f \n", surface_making, sqrt(var_rep[j]));
     }
     fclose(fitfile);

// pred mean and sd
     for(j=0; j < nsite1*size1; j++){
          mn_pred[j] = mn_pred[j]/iit[0];
          var_pred[j] = var_pred[j]/iit[0];
          var_pred[j] = var_pred[j] - mn_pred[j]*mn_pred[j];
          fprintf(prdfile, "%f , %f \n", mn_pred[j], sqrt(var_pred[j]));
     }
     fclose(prdfile); 
     free(mn_pred); free(var_pred); free(iit); 	
   

     double pen, go;
     pen =0;
     go =0;
     
// pmcc          
     for(j=0; j < N1; j++){
         if (flag[j] == 1.0){
          mn_rep[j] = 0.0;
          var_rep[j] = 0.0;
         }
         else{
          mn_rep[j] = mn_rep[j];
          var_rep[j] = var_rep[j];
          mn_rep[j] = (mn_rep[j] - z[j])*(mn_rep[j] - z[j]);          
         }
         pen += var_rep[j]; 
         go += mn_rep[j];
     }

     penalty[0] = pen;
     gof[0] = go;       
     free(mn_rep); free(var_rep); 

     Rprintf(" ... ");
     Rprintf("\n---------------------------------------------------------\n");
       
     return;
}

void GIBBS_sumpred_gpp(int *aggtype, int *cov, int *spdecay, double *flag, 
     int *its, int *burnin,
     int *n, int *m, int *T, int *r, int *rT, int *p, int *N, int *report,
     double *shape_e, double *shape_eta, double *shape_l,  
     double *phi_a, double *phi_b,
     double *prior_a, double *prior_b, double *mu_beta, double *delta2_beta,
     double *mu_rho,  double *delta2_rho, double *alpha_l, double *delta2_l,
     double *phi, double *tau, double *phis, int *phik,
     double *dm, double *dnm, int *constant, 
     double *sig2e, double *sig2eta, double *sig2l, double *beta, 
     double *rho, double *mu_l, double *X, double *z, double *w0, double *w,
     int *nsite, int *nsiterT, double *dnsm, double *Xpred, int *transform, 
     double *accept_f, double *gof, double *penalty)    
{
//     unsigned iseed = 44;
//     srand(iseed); 
     
     int its1, col, i, j, n1, m1, r1, rT1, p1, N1, rep1, nsite1, brin, trans1;
     its1 = *its;
     col = *constant;
     n1 = *n;
     m1 = *m;
     r1 = *r;
     rT1 = *rT;
     p1 = *p;
     N1 = *N;
     rep1 = *report;
     nsite1 = *nsite;
     brin = *burnin;
     trans1 = *transform;

     double accept1, *mn_rep, *var_rep, *mn_pred, *var_pred, *mn_pred_sq, *var_pred_sq, *mn_rep_2, *var_rep_2;
     mn_rep = (double *) malloc((size_t)((N1)*sizeof(double)));          
     var_rep = (double *) malloc((size_t)((N1)*sizeof(double)));          
     mn_pred = (double *) malloc((size_t)((nsite1*rT1)*sizeof(double)));          
     var_pred = (double *) malloc((size_t)((nsite1*rT1)*sizeof(double)));  

     mn_pred_sq = (double *) malloc((size_t)((nsite1*rT1)*sizeof(double)));          
     var_pred_sq = (double *) malloc((size_t)((nsite1*rT1)*sizeof(double)));  
     mn_rep_2 = (double *) malloc((size_t)((N1)*sizeof(double)));          
     var_rep_2 = (double *) malloc((size_t)((N1)*sizeof(double)));
              

     accept1 = 0.0;

     for(j=0; j<N1; j++){
        mn_rep[j] = 0.0;
        var_rep[j] = 0.0;
        mn_rep_2[j] = 0.0;
        var_rep_2[j] = 0.0;
     }      
     for(j=0; j<nsite1*rT1; j++){
        mn_pred[j] = 0.0;
        var_pred[j] = 0.0;
        mn_pred_sq[j] = 0.0;
        var_pred_sq[j] = 0.0;
     }      

     double *phip, *sig2ep, *sig2etap, *rhop, *betap;
     double *mu_lp, *sig2lp, *wp, *w0p, *zfit, *ofit, *acc;
     phip = (double *) malloc((size_t)((col)*sizeof(double)));          
     sig2ep = (double *) malloc((size_t)((col)*sizeof(double)));
     sig2etap = (double *) malloc((size_t)((col)*sizeof(double)));
     rhop = (double *) malloc((size_t)((col)*sizeof(double)));
     betap = (double *) malloc((size_t)((p1)*sizeof(double)));          
     mu_lp = (double *) malloc((size_t)((r1)*sizeof(double)));    
     sig2lp = (double *) malloc((size_t)((r1)*sizeof(double))); 
     wp = (double *) malloc((size_t)((m1*rT1)*sizeof(double))); 
     w0p = (double *) malloc((size_t)((m1*r1)*sizeof(double))); 
     zfit = (double *) malloc((size_t)((N1)*sizeof(double)));
     ofit = (double *) malloc((size_t)((N1)*sizeof(double)));     
     acc = (double *) malloc((size_t)((col)*sizeof(double)));

     double *phi1, *sig2e1, *sig2eta1, *rho1, *beta1, *w01, *w1;
     double *diff_z_xb;
     phi1 = (double *) malloc((size_t)((col)*sizeof(double)));
     sig2e1 = (double *) malloc((size_t)((col)*sizeof(double)));
     sig2eta1 = (double *) malloc((size_t)((col)*sizeof(double)));
     rho1 = (double *) malloc((size_t)((col)*sizeof(double)));
     beta1 = (double *) malloc((size_t)((p1*col)*sizeof(double)));     
     w01 = (double *) malloc((size_t)((m1*r1)*sizeof(double))); 
     w1 = (double *) malloc((size_t)((m1*rT1)*sizeof(double))); 
     diff_z_xb = (double *) malloc((size_t)((N1)*sizeof(double)));

     double *zp, *anf; //, tmp[T1];
     zp = (double *) malloc((size_t)((nsite1*rT1)*sizeof(double)));      
     anf = (double *) malloc((size_t)((nsite1*r1)*sizeof(double)));      

     double *nu, *nup;
     nu = (double *) malloc((size_t)((col)*sizeof(double)));
     nup = (double *) malloc((size_t)((col)*sizeof(double)));     
     nu[0] = 0.5;
          
       ext_sige(phi, phi1);
       ext_sige(sig2e, sig2e1);
       ext_sigeta(sig2eta, sig2eta1);
       ext_rho(rho, rho1);
       ext_beta(p, beta, beta1);
       for(j=0; j<m1*rT1; j++){
         w1[j] = w[j];
       }     
       for(j=0; j<m1*r1; j++){
         w01[j] = w0[j];
       }     

     FILE *parafile;
     parafile = fopen("OutGPP_Values_Parameter.txt", "w");
     FILE *siglfile;
     siglfile = fopen("OutGPP_Values_sigl.txt", "w");
     FILE *wfile;
     wfile = fopen("OutGPP_Values_w.txt", "w");
     FILE *w0file;
     w0file = fopen("OutGPP_Values_w0.txt", "w");
     FILE *fitfile;
     fitfile = fopen("OutGPP_Stats_FittedValue.txt", "w");
     FILE *prdfile;
     prdfile = fopen("OutGPP_Stats_PredValue.txt", "w");
     FILE *predfile;
     predfile = fopen("OutGPP_Values_Prediction.txt", "w");

     int type1;
     type1= *aggtype;
   
     FILE *textan;
     // none
     if(type1==0){
       textan = fopen("OutGPP_NONE.txt", "w");
     }
     // annual average value
     if(type1==1){
       textan = fopen("OutGPP_Annual_Average_Prediction.txt", "w");
     }
     // annual 4th highest value
     if(type1==2){
       textan = fopen("OutGPP_Annual_4th_Highest_Prediction.txt", "w");
     }
     // annual w126 option
     if(type1==3){
       textan = fopen("OutGPP_Annual_w126_Prediction.txt", "w");
     }

     GetRNGstate();            
     for(i=0; i < its1; i++) {

     JOINT_onephi_gpp_fixed(cov, spdecay, flag, n, m, T, r, rT, p, N, 
     shape_e, shape_eta, shape_l, 
     phi_a, phi_b,
     prior_a, prior_b, mu_beta, delta2_beta, 
     mu_rho, delta2_rho, alpha_l, delta2_l, phi1, tau, phis, phik, nu, dm, dnm, 
     constant, sig2e1, sig2eta1, sig2l, beta1, rho1, mu_l, X, z, w01, w1, 
     phip, acc, nup, sig2ep, sig2etap, betap, rhop, mu_lp, sig2lp, w0p, wp, zfit, diff_z_xb);  

     z_pr_gpp1(cov, nsite, n, m, r, T, rT, p, nsiterT, phip, nup, dm, dnsm, 
     wp, sig2ep, betap, Xpred, constant, zp);

     accept1 += acc[0];

     for(j=0; j < p1; j++){
     fprintf(parafile, "%f ", betap[j]);
     }         
     fprintf(parafile, "%f ", rhop[0]);
     fprintf(parafile, "%f ", sig2ep[0]);
     fprintf(parafile, "%f ", sig2etap[0]);
     fprintf(parafile, "%f ", phip[0]);
     if(cov[0]==4){
      fprintf(parafile, "%f ", nup[0]);
     }     
     fprintf(parafile, "\n");
        
     /*for(j=0; j < r1; j++){
     fprintf(siglfile, "%f\n", sig2lp[j]);
     }
     for(j=0; j < m1*r1; j++){
     fprintf(w0file, "%f ", w0p[j]);
     }
     fprintf(w0file, "\n");
     for(j=0; j < m1*rT1; j++){
     fprintf(wfile, "%f ", wp[j]);
     }
     fprintf(wfile, "\n");
     */
 
//for square-root mean and variance of predicted values
for(j=0; j<(nsite1*rT1); j++)
{
  if(i >= brin){  
  mn_pred_sq[j] += zp[j];
  var_pred_sq[j] += zp[j]*zp[j];
  }
}



// for pmcc, fitted sum values    
     for(j=0; j < N1; j++){
         if(i >= brin){  
          mn_rep[j] += zfit[j];
          var_rep[j] += zfit[j]*zfit[j];

          if(trans1 == 0){
          mn_rep_2[j] += zfit[j];
          }
          if(trans1 == 1){
          mn_rep_2[j] += (zfit[j]*zfit[j]);
          }
          if(trans1 == 2){
          mn_rep_2[j] += exp(zfit[j]);
          }
          var_rep_2[j] += (zfit[j]*zfit[j]);
         } 
     }


// prediction samples
     if(i >= brin){
     for(j=0; j<(nsite1*rT1); j++){
         if(trans1 == 0){
           zp[j] = zp[j];
           fprintf(predfile, "%f ", zp[j]);
         }
         if(trans1 == 1){
           zp[j] = zp[j]*zp[j];
           fprintf(predfile, "%f ", zp[j]);
         }
         if(trans1 == 2){
           zp[j] = exp(zp[j]);
           fprintf(predfile, "%f ", zp[j]);
         }
     }                            
     fprintf(predfile, "\n");
     }	

// prediction samples summary
     for(j=0; j<(nsite1*rT1); j++){
         if(i >= brin){  
          mn_pred[j] += zp[j];
          var_pred[j] += zp[j]*zp[j];
         }
     }

       ext_sige(phip, phi1);
       ext_sige(sig2ep, sig2e1);
       ext_sigeta(sig2etap, sig2eta1); 
       ext_rho(rhop, rho1); 
       ext_beta(p, betap, beta1);              
       for(j=0; j<m1*rT1; j++){
         w1[j] = wp[j];
       }     
       for(j=0; j<m1*r1; j++){
         w01[j] = w0p[j];
       }     

     if(cov[0]==4){
     para_printRnu (i, its1, rep1, p1, accept1, phip, nup, rhop, sig2ep, sig2etap, betap); 
     }                   
     else {              
     para_printR (i, its1, rep1, p1, accept1, phip, rhop, sig2ep, sig2etap, betap); 
     }

      if(i >= brin){
         annual_aggregate_uneqT(aggtype, nsite, r, T, rT, zp, anf);
//         annual_aggregate(aggtype, nsite, r, T, zp, anf);
  	     for(j=0; j<(nsite1*r1); j++){
           fprintf(textan, "%f ", anf[j]);
         }
         fprintf(textan, "\n");
/*
       // annual average value
       if(type1==1){
         annual_aggregate(aggtype, nsite, r, T, zp, anf);
  	     for(j=0; j<(nsite1*r1); j++){
           fprintf(textan, "%f ", anf[j]);
         }
         fprintf(textan, "\n");
       }
       // annual 4th highest value
       if(type1==2){
         annual_aggregate(aggtype, nsite, r, T, zp, anf);
  	     for(j=0; j<(nsite1*r1); j++){
           fprintf(textan, "%f ", anf[j]);
         }
         fprintf(textan, "\n");
       }     
       // annual w126 
       if(type1==3){
         annual_aggregate(aggtype, nsite, r, T, zp, anf);
  	     for(j=0; j<(nsite1*r1); j++){
           fprintf(textan, "%f ", anf[j]);
         }
         fprintf(textan, "\n");
       }     
*/
      } // end of loop i >= brin
     } // end of iteration loop
     PutRNGstate();

     fclose(parafile);
     fclose(predfile);
     fclose(textan);
     fclose(siglfile);
     fclose(w0file);
     fclose(wfile);

    free(phip); free(sig2ep); free(sig2etap); free(rhop); free(betap);
    free(mu_lp); free(sig2lp); free(wp); free(w0p); free(zfit); free(ofit); 
    free(acc);  free(diff_z_xb); 
    free(phi1); free(sig2e1); free(sig2eta1); free(rho1); free(beta1);
    free(zp); free(anf);  

     Rprintf(" Calculating Summary Statistics \n ... ");

     accept_f[0] = accept1;

//     int iit;
//     iit = 0;
//     iit = its1 - brin;

	int *iit;
    iit = (int *) malloc((size_t)((col)*sizeof(int)));
	iit[0] = its[0] - burnin[0];

// fitted zlt, mean and sd
     for(j=0; j < N1; j++){
          mn_rep[j] = mn_rep[j]/iit[0];
          var_rep[j] = var_rep[j]/iit[0];
          var_rep[j] = var_rep[j] - (mn_rep[j]*mn_rep[j]);

          mn_rep_2[j] = mn_rep_2[j]/iit[0];
          var_rep_2[j] = var_rep_2[j]/iit[0];
          var_rep_2[j] = var_rep_2[j] - (mn_rep_2[j]*mn_rep_2[j]);
          fprintf(fitfile, "%f , %f , %f , %f \n", mn_rep_2[j], sqrt(var_rep_2[j]), mn_rep[j], sqrt(var_rep[j]));
     }
     fclose(fitfile);

// pred mean and sd
     for(j=0; j < nsite1*rT1; j++){
          mn_pred[j] = mn_pred[j]/iit[0];
          var_pred[j] = var_pred[j]/iit[0];
          var_pred[j] = var_pred[j] - mn_pred[j]*mn_pred[j];

          mn_pred_sq[j] = mn_pred_sq[j]/iit[0];
          var_pred_sq[j] = var_pred_sq[j]/iit[0];
          var_pred_sq[j] = var_pred_sq[j] - (mn_pred_sq[j]*mn_pred_sq[j]);
          fprintf(prdfile, "%f , %f , %f , %f\n", mn_pred[j], sqrt(var_pred[j]), mn_pred_sq[j], sqrt(var_pred_sq[j]));
     }
     fclose(prdfile);
     free(mn_pred); free(var_pred); free(iit); 	free(mn_pred_sq); free(var_pred_sq); 
   

     double pen, go;
     pen =0;
     go =0;
     
// pmcc          
     for(j=0; j < N1; j++){
         if (flag[j] == 1.0){
          mn_rep[j] = 0.0;
          var_rep[j] = 0.0;
         }
         else{
          mn_rep[j] = mn_rep[j];
          var_rep[j] = var_rep[j];
          mn_rep[j] = (mn_rep[j] - z[j])*(mn_rep[j] - z[j]);          
         }
         pen += var_rep[j]; 
         go += mn_rep[j];
     }

     penalty[0] = pen;
     gof[0] = go;       
     free(mn_rep); free(var_rep); free(mn_rep_2); free(var_rep_2); 

     Rprintf(" ... ");
     Rprintf("\n---------------------------------------------------------\n");
       
     return;
}



// with zfit summary values (mean and variance/sd)
// with one phi parameter
void GIBBS_zfitsum_onephi_gpp(int *cov, int *spdecay, double *flag, int *its, int *burnin,
     int *n, int *m, int *T, int *r, int *rT, int *p, int *N, int *report,
     double *shape_e, double *shape_eta, double *shape_l,  
     double *phi_a, double *phi_b,
     double *prior_a, double *prior_b, double *mu_beta, double *delta2_beta,
     double *mu_rho,  double *delta2_rho, double *alpha_l, double *delta2_l,
     double *phi_eta, double *tau_eta, double *phis, int *phik, 
     double *dm, double *dnm, int *constant, 
     double *sig2e, double *sig2eta, double *sig2l, double *beta, 
     double *rho, double *mu_l, double *X, double *z, double *w0, double *w,
     int *transform, double *phi_etaf, double *accept_etaf, double *nupf,
     double *sig2ef, double *sig2etaf, double *betaf, double *rhof, 
     double *mu_lf, double *sig2lf, double *w0f, double *wf, 
     double *gof, double *penalty, double *z_mean_sd)
{
//     unsigned iseed = 44;
//     srand(iseed); 
     
     int its1, col, i, j, n1, m1, r1, T1, p1, N1, rep1, brin, trans1;
     its1 = *its;
     col = *constant;
     n1 = *n;
     m1 = *m;
     r1 = *r;
     T1 = *T;
     p1 = *p;
     N1 = *N;
     rep1 = *report;
     brin = *burnin;
     trans1 = *transform;

     double accept1; //, mn_rep[N1], var_rep[N1];
     accept1 = 0.0;
     double *mn_rep, *var_rep;
     mn_rep = (double *) malloc((size_t)((N1)*sizeof(double)));          
     var_rep = (double *) malloc((size_t)((N1)*sizeof(double)));          

     for(j=0; j<N1; j++){
        mn_rep[j] = 0.0;
        var_rep[j] = 0.0;
     }      

     double *phi_etap, *sig2ep, *sig2etap, *rhop, *betap;
     double *mu_lp, *sig2lp, *wp, *w0p, *zfit;
     double *phi_eta1, *sig2e1, *sig2eta1, *rho1, *beta1;
     double *mu_l1, *sig2l1, *w01, *w1;
     double *acc_eta, *out; // *z1;
          
     phi_etap = (double *) malloc((size_t)((1)*sizeof(double)));          
     sig2ep = (double *) malloc((size_t)((1)*sizeof(double)));
     sig2etap = (double *) malloc((size_t)((1)*sizeof(double)));
     rhop = (double *) malloc((size_t)((1)*sizeof(double)));
     betap = (double *) malloc((size_t)((p1)*sizeof(double)));          
     mu_lp = (double *) malloc((size_t)((r1)*sizeof(double)));    
     sig2lp = (double *) malloc((size_t)((r1)*sizeof(double))); 
     wp = (double *) malloc((size_t)((m1*r1*T1)*sizeof(double))); 
     w0p = (double *) malloc((size_t)((m1*r1)*sizeof(double))); 
     zfit = (double *) malloc((size_t)((N1)*sizeof(double)));

     phi_eta1 = (double *) malloc((size_t)((1)*sizeof(double)));
     sig2e1 = (double *) malloc((size_t)((1)*sizeof(double)));
     sig2eta1 = (double *) malloc((size_t)((1)*sizeof(double)));
     rho1 = (double *) malloc((size_t)((1)*sizeof(double)));
     beta1 = (double *) malloc((size_t)((p1)*sizeof(double)));     
     mu_l1 = (double *) malloc((size_t)((r1)*sizeof(double)));    
     sig2l1 = (double *) malloc((size_t)((r1)*sizeof(double))); 
     w01 = (double *) malloc((size_t)((m1*r1)*sizeof(double))); 
     w1 = (double *) malloc((size_t)((m1*r1*T1)*sizeof(double))); 
     
     acc_eta = (double *) malloc((size_t)((1)*sizeof(double)));
     out = (double *) malloc((size_t)((1)*sizeof(double)));     
//     z1 = (double *) malloc((size_t)((N1)*sizeof(double)));

     double *nu, *nup;
     nu = (double *) malloc((size_t)((1)*sizeof(double)));
     nup = (double *) malloc((size_t)((1)*sizeof(double)));     
     nu[0] = 2.0/3.0;
          
       ext_sige(phi_eta, phi_eta1);
       ext_sige(sig2e, sig2e1);
       ext_sigeta(sig2eta, sig2eta1);
       ext_rho(rho, rho1);
       ext_beta(p, beta, beta1);
       ext_mul(r, mu_l, mu_l1);
       ext_sigl(r, sig2l, sig2l1);
//       ext_o(N, z, z1);
       for(j=0; j<m1*r1*T1; j++){
         w1[j] = w[j];
       }     
       for(j=0; j<m1*r1; j++){
         w01[j] = w0[j];
       }     
            
/*
// for missing
     for(j=0; j < N1; j++){
          if (flag[j] == 1.0){
          out[0]=z[j];
          mvrnormal(constant, out, sig2e1, constant, out);  
          z1[j] =  out[0];
          }
          else {
          z1[j] = z[j];
          }     
     }
*/

     GetRNGstate();
     for(i=0; i < its1; i++) {

     JOINT_onephi_gpp(cov, spdecay, flag, n, m, T, r, rT, p, N, 
     shape_e, shape_eta, shape_l, 
     phi_a, phi_b,
     prior_a, prior_b, mu_beta, delta2_beta, 
     mu_rho, delta2_rho, alpha_l, delta2_l, phi_eta1, tau_eta, phis, phik, nu, 
     dm, dnm, constant, sig2e1, sig2eta1, sig2l1, beta1, rho1, mu_l1, X, z, 
     w01, w1, phi_etap, acc_eta, nup, sig2ep, sig2etap, betap, rhop, mu_lp, sig2lp, 
     w0p, wp, zfit);

     accept1 += acc_eta[0];
        
     phi_etaf[i] = phi_etap[0];
     nupf[i] = nup[0];
     
     sig2ef[i] = sig2ep[0];
     sig2etaf[i] = sig2etap[0];
     rhof[i] = rhop[0];
     for(j=0; j < r1; j++) {
         sig2lf[j+i*r1] = sig2lp[j];     
     }
     for(j=0; j < p1; j++){
         betaf[j+i*p1] = betap[j];
     }         
     for(j=0; j < r1; j++) {
         mu_lf[j+i*r1] = mu_lp[j];     
     }
     for(j=0; j<m1*r1; j++){
         w0f[j+i*m1*r1] = w0p[j];
     }     
     for(j=0; j<m1*r1*T1; j++){
         wf[j+i*m1*r1*T1] = wp[j];
     }     


// for pmcc, fitted sum values    
     for(j=0; j < N1; j++){
         if(i >= brin){  
          mn_rep[j] += zfit[j];
          var_rep[j] += zfit[j]*zfit[j];
         } 
     }

       ext_sige(phi_etap, phi_eta1);
       ext_sige(nup, nu);       
       ext_sige(sig2ep, sig2e1);
       ext_sigeta(sig2etap, sig2eta1); 
       ext_rho(rhop, rho1); 
       ext_beta(p, betap, beta1);              
       for(j=0; j<m1*r1*T1; j++){
         w1[j] = wp[j];
       }     
       for(j=0; j<m1*r1; j++){
         w01[j] = w0p[j];
       }     

     if(cov[0]==4){
     para_printRnu (i, its1, rep1, p1, accept1, phi_etap, nup, rhop, sig2ep, sig2etap, betap); 
     }                   
     else {              
     para_printR (i, its1, rep1, p1, accept1, phi_etap, rhop, sig2ep, sig2etap, betap); 
     }
//     printR(i, its1); 
     
     } // end of iteration loop
     PutRNGstate();

     free(phi_etap); free(nu); free(nup); free(sig2ep); free(sig2etap); 
     free(rhop); free(betap); free(mu_lp); free(sig2lp); free(wp); free(w0p); 
     free(zfit); free(phi_eta1); free(sig2e1); free(sig2eta1); free(rho1); 
     free(beta1); free(mu_l1); free(sig2l1); free(acc_eta); free(out); 
     //free(z1);  
     free(w01); free(w1); 

     accept_etaf[0] = accept1;

	int *iit;
    iit = (int *) malloc((size_t)((col)*sizeof(int)));
	iit[0] = its[0] - burnin[0];

// fitted zlt, mean and sd
     for(j=0; j < N1; j++){
          mn_rep[j] = mn_rep[j]/iit[0];
          var_rep[j] = var_rep[j]/iit[0];
          var_rep[j] = var_rep[j] - mn_rep[j]*mn_rep[j];
          z_mean_sd[j] = mn_rep[j];
          z_mean_sd[N1+j] = sqrt(var_rep[j]);
     }

     double pen, go;
     pen = 0;
     go =0;

// pmcc          
     for(j=0; j < N1; j++){
         if (flag[j] == 1.0){
          mn_rep[j] = 0.0;
          var_rep[j] = 0.0;
         }
         else{
          mn_rep[j] = mn_rep[j];
          var_rep[j] = var_rep[j];
          mn_rep[j] = (mn_rep[j] - z[j])*(mn_rep[j] - z[j]);          
         }
         pen += var_rep[j]; 
         go += mn_rep[j];
     }
     penalty[0] = pen;
     gof[0] = go;       

     free(mn_rep); free(var_rep); free(iit);
     
     return;
}



// for spatially varying GPP
// with zfit summary values (mean and variance/sd)
// with one phi parameter
void GIBBSsp_zfitsum_onephi_gpp(int *intercept, int *cov, int *spdecay, 
     double *flag, int *its, int *burnin, int *n, int *m, int *T, int *r, 
     int *rT, int *p, int *q, int *N, int *report, double *shape_e, 
     double *shape_eta, double *shape_beta, double *shape_l, double *prior_a, 
     double *prior_b, double *mu_beta, double *delta2_beta, double *mu_rho,  
     double *delta2_rho, double *alpha_l, double *delta2_l, double *phi_eta, 
     double *tau_eta, double *phis, int *phik, double *dm, double *dnm, 
     int *constant, 
     double *sig2e, double *sig2eta, double *sig2beta, double *sig2l, 
     double *beta, double *betas, double *rho, double *mu_l, double *X, 
     double *Xsp, double *z, double *w0, double *w, int *transform, 
     double *phi_etaf, double *accept_etaf, double *nupf, double *sig2ef, 
     double *sig2etaf, double *sig2betaf, double *betaf, double *betaspf, 
     double *rhof, double *mu_lf, double *sig2lf, double *w0f, double *wf, 
     double *gof, double *penalty, double *z_mean_sd)
{
//     unsigned iseed = 44;
//     srand(iseed); 
     
     int its1, col, i, j, n1, m1, r1, T1, p1, q1, N1, rep1, brin, trans1;
     its1 = *its;
     col = *constant;
     n1 = *n;
     m1 = *m;
     r1 = *r;
     T1 = *T;
     p1 = *p;
     q1 = *q;
     N1 = *N;
     rep1 = *report;
     brin = *burnin;
     trans1 = *transform;


     double accept1; 
     accept1 = 0.0;
     double *mn_rep, *var_rep;
     mn_rep = (double *) malloc((size_t)((N1)*sizeof(double)));          
     var_rep = (double *) malloc((size_t)((N1)*sizeof(double)));          

     for(j=0; j<N1; j++){
        mn_rep[j] = 0.0;
        var_rep[j] = 0.0;
     }      

     double *phi_etap, *sig2ep, *sig2etap, *sig2betap, *rhop, *betap, *betasp;
     double *mu_lp, *sig2lp, *wp, *w0p, *zfit;
     double *phi_eta1, *sig2e1, *sig2eta1, *sig2beta1, *rho1, *beta1;
     double *mu_l1, *sig2l1; //, *w01, *w1;
     double *acc_eta, *out; // *z1;
          
     phi_etap = (double *) malloc((size_t)((col)*sizeof(double)));          
     sig2ep = (double *) malloc((size_t)((col)*sizeof(double)));
     sig2etap = (double *) malloc((size_t)((col)*sizeof(double)));
     sig2betap = (double *) malloc((size_t)((col)*sizeof(double)));
     rhop = (double *) malloc((size_t)((col)*sizeof(double)));
     betap = (double *) malloc((size_t)((p1*col)*sizeof(double)));          
     betasp = (double *) malloc((size_t)((q1*m1)*sizeof(double)));          
     mu_lp = (double *) malloc((size_t)((r1*col)*sizeof(double)));    
     sig2lp = (double *) malloc((size_t)((r1*col)*sizeof(double))); 
     wp = (double *) malloc((size_t)((m1*r1*T1)*sizeof(double))); 
     w0p = (double *) malloc((size_t)((m1*r1)*sizeof(double))); 
     zfit = (double *) malloc((size_t)((N1*col)*sizeof(double)));

     phi_eta1 = (double *) malloc((size_t)((col)*sizeof(double)));
     sig2e1 = (double *) malloc((size_t)((col)*sizeof(double)));
     sig2eta1 = (double *) malloc((size_t)((col)*sizeof(double)));
     sig2beta1 = (double *) malloc((size_t)((col)*sizeof(double)));
     rho1 = (double *) malloc((size_t)((col)*sizeof(double)));
     beta1 = (double *) malloc((size_t)((p1*col)*sizeof(double)));     
     mu_l1 = (double *) malloc((size_t)((r1*col)*sizeof(double)));    
     sig2l1 = (double *) malloc((size_t)((r1*col)*sizeof(double))); 
     
     acc_eta = (double *) malloc((size_t)((col)*sizeof(double)));
     out = (double *) malloc((size_t)((col)*sizeof(double)));     

     double *nu, *nup;
     nu = (double *) malloc((size_t)((col)*sizeof(double)));
     nup = (double *) malloc((size_t)((col)*sizeof(double)));     
     nu[0] = 2.0/3.0;
          
       ext_sige(phi_eta, phi_eta1);
       ext_sige(sig2e, sig2e1);
       ext_sigeta(sig2eta, sig2eta1);
       ext_sigeta(sig2beta, sig2beta1);
       ext_rho(rho, rho1);
       ext_beta(p, beta, beta1);
       ext_mul(r, mu_l, mu_l1);
       ext_sigl(r, sig2l, sig2l1);

     GetRNGstate();
     for(i=0; i < its1; i++) {


     JOINT_onephi_sp_gpp(intercept, cov, spdecay, flag, n, m, T, r, rT, p, q,
     N, shape_e, shape_eta, shape_beta, shape_l, prior_a, prior_b, mu_beta, 
     delta2_beta, mu_rho, delta2_rho, alpha_l, delta2_l, phi_eta1, tau_eta,
     phis, phik, nu, dm, dnm, constant, sig2e1, sig2eta1, sig2beta1, sig2l1,
     beta1, betas, rho1, mu_l1, X, Xsp, z, w0, w, phi_etap, acc_eta, nup, 
     sig2ep, sig2etap, sig2betap, betap, betasp, rhop, mu_lp, sig2lp, w0p, wp,
     zfit);
     
     accept1 += acc_eta[0];
        
     phi_etaf[i] = phi_etap[0];
     nupf[i] = nup[0];
     
     sig2ef[i] = sig2ep[0];
     sig2etaf[i] = sig2etap[0];
     sig2betaf[i] = sig2betap[0];
     rhof[i] = rhop[0];
     for(j=0; j < r1; j++) {
         sig2lf[j+i*r1] = sig2lp[j];     
     }
     for(j=0; j < p1; j++){
         betaf[j+i*p1] = betap[j];
     }         
     for(j=0; j < m1*q1; j++){
         betaspf[j+i*m1*q1] = betasp[j];
     }         
     for(j=0; j < r1; j++) {
         mu_lf[j+i*r1] = mu_lp[j];     
     }
     for(j=0; j<m1*r1; j++){
         w0f[j+i*m1*r1] = w0p[j];
     }     
     for(j=0; j<m1*r1*T1; j++){
         wf[j+i*m1*r1*T1] = wp[j];
     }     

// for pmcc, fitted sum values    
     for(j=0; j < N1; j++){
         if(i >= brin){  
          mn_rep[j] += zfit[j];
          var_rep[j] += zfit[j]*zfit[j];
         } 
     }

       ext_sige(phi_etap, phi_eta1);
       ext_sige(nup, nu);       
       ext_sige(sig2ep, sig2e1);
       ext_sigeta(sig2etap, sig2eta1); 
       ext_rho(rhop, rho1); 
       ext_beta(p, betap, beta1);              
//       for(j=0; j < m1; j++){
//         betas[j] = betasp[j];
//       }         

     if(cov[0]==4){
     GPPsp_para_printRnu(i, its1, rep1, p1, accept1, phi_etap, nup, rhop, sig2ep, sig2etap, sig2betap, betap); 
     }                   
     else {              
     GPPsp_para_printR(i, its1, rep1, p1, accept1, phi_etap, rhop, sig2ep, sig2etap, sig2betap, betap); 
     }

    
     } // end of iteration loop
     PutRNGstate();

     free(phi_etap); free(nu); free(nup); free(sig2ep); free(sig2etap); free(sig2betap);
     free(rhop); free(betap); free(betasp); free(mu_lp); free(sig2lp); free(wp); free(w0p); 
     free(zfit); free(phi_eta1); free(sig2e1); free(sig2eta1); free(sig2beta1); free(rho1); 
     free(beta1); free(mu_l1); free(sig2l1); free(acc_eta); free(out); 

     accept_etaf[0] = accept1;

	int *iit;
    iit = (int *) malloc((size_t)((col)*sizeof(int)));
	iit[0] = its[0] - burnin[0];

// fitted zlt, mean and sd
     for(j=0; j < N1; j++){
          mn_rep[j] = mn_rep[j]/iit[0];
          var_rep[j] = var_rep[j]/iit[0];
          var_rep[j] = var_rep[j] - mn_rep[j]*mn_rep[j];
          z_mean_sd[j] = mn_rep[j];
          z_mean_sd[N1+j] = sqrt(var_rep[j]);
     }

     double pen, go;
     pen = 0;
     go =0;

// pmcc          
     for(j=0; j < N1; j++){
         if (flag[j] == 1.0){
          mn_rep[j] = 0.0;
          var_rep[j] = 0.0;
         }
         else{
          mn_rep[j] = mn_rep[j];
          var_rep[j] = var_rep[j];
          mn_rep[j] = (mn_rep[j] - z[j])*(mn_rep[j] - z[j]);          
         }
         pen += var_rep[j]; 
         go += mn_rep[j];
     }
     penalty[0] = pen;
     gof[0] = go;       

     free(mn_rep); free(var_rep); free(iit);

     return;
}


/////////////////////////// THE END ////////////////////////////
