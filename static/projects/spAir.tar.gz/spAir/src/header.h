/*****************************************************************************/
/*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
//#include <malloc.h>
#include <assert.h>
#include <stdlib.h>
//#include <conio.h>
#include <float.h>
#include <unistd.h>

// GUI library
//#include <gsl_rng.h>
//#include <gsl_randist.h>

#include <R.h>
#include <Rmath.h>
#include <Rinternals.h>

#include <R_ext/Print.h>

//#define PI    3.14159265358979323846 



/*****************************************************************************/
/*****************************************************************************/


